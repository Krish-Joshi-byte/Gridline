# Gridline Scan — handoff v6 (Sep 19, 2026)

**This release fixes the dark screen.** Two separate faults, both fatal, both now fixed and verified.
`HANDOFF-v5.md` (previous release) and `HANDOFF-apartment-model.md` are kept alongside this file; nothing was deleted.

---

## 1. Why the page was dark

The scene data was never the problem. The model in `apartment_2bed2bath_2d.scene.json` is complete and
correct — 1,027 wall rectangles, 10 rooms, sane coordinates — and it renders into a recognisable
apartment (see `output/apartment_2bed2bath_2d.preview.png`, which was rasterised straight from the
scene graph, outside any browser). The page died before it could draw a single frame.

### Fault 1 — a variable used before it was declared (this one is the killer)

In `frontend/viewer.template.html` the boot sequence ran at line ~158:

```js
init(); build(data); animate();
```

and `animate()` reads `prev` on its very first line. But `prev` was declared **400 lines further down**:

```js
let prev = performance.now();
```

`let` bindings are in a *temporal dead zone* until their declaration is evaluated, so the first call to
`animate()` threw `ReferenceError: Cannot access 'prev' before initialization`. That aborts the whole
script: no renderer loop, no error anyone could see, just `<body>` painted in `--bg` (`#0b0f14`) —
a dark screen. **Every model file generated from the v5 template had this.**

Fix: `prev` is declared with the rest of the state, above first use. `var` would also have worked; the
declaration was simply in the wrong place.

### Fault 2 — two CDN scripts, one of which does not exist

Both the template and `frontend/index.html` loaded:

```
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/examples/js/controls/OrbitControls.js
```

cdnjs does **not** publish three.js's `examples/` folder, so the second URL 404s. The template happened
to carry its own fallback controls, so it survived that; `index.html` had no fallback and would throw
`THREE.OrbitControls is not a constructor` — dark screen again. And if `three.min.js` itself is blocked
(offline laptop, `file://` with no network, locked-down agency network, a sandbox that blocks
third-party scripts) then `THREE` is undefined and everything dies.

Fix: **nothing is fetched over the network any more.** `three.js` r128 is vendored into
`frontend/vendor/three.min.js` and inlined into each generated model file. The orbit controls live in
`frontend/vendor/orbit-controls.js` and are inlined too. A generated model is one file with **zero
external requests** — it works from a USB stick, offline, on any network.

### Fault 3 (not fatal, but it hid the other two)

A failure before the first frame produced no visible message. Now any exception during boot, a missing
`THREE`, or a browser with no WebGL context paints a readable panel on the page saying what happened.
**A dark rectangle is no longer a possible outcome.**

---

## 2. What changed, file by file

| File | Change |
|---|---|
| `frontend/viewer.template.html` | `prev` moved above first use (Fault 1); CDN tags replaced by `__THREE_JS__` inline slot; boot wrapped in try/catch with a WebGL probe; on-page error panel + styling |
| `frontend/vendor/three.min.js` | **new** — three.js r128, 603 KB, vendored |
| `frontend/vendor/orbit-controls.js` | **new** — the minimal controls, extracted from the template so `index.html` can share them |
| `frontend/index.html` | CDN tags → local `vendor/` scripts; it had no controls fallback and was broken |
| `frontend/build-viewer.js` | **new** — build a model file without a JDK: `node frontend/build-viewer.js <scene.json> <plan.png\|-> <out.html> ["Title"]` |
| `backend/src/com/gridlinescan/FloorplanTo3D.java` | `writeViewer` now inlines `vendor/three.min.js`, refuses to run if it is missing or contains a `</script` sequence, and uses an explicit literal replace for the 600 KB payload. Compiles clean |
| `output/*.model.html` | all six regenerated, self-contained, each verified to boot |
| `output/apartment_2bed2bath_2d.preview.png` | **new** — offline render proving the geometry is right |

---

## 3. How to use it

### Just open a model
Double-click any `output/*.model.html`. No server, no network, no build step.
`output/apartment_2bed2bath_2d.model.html` is the 2 bed / 2 bath unit; it is also published in Claude.

**Controls** — *Orbit*: drag to rotate, scroll to zoom, right-drag to pan. *Walk inside*: W/A/S/D or
arrows to move, Shift to run, drag to look; eye height 1.6 m and the walls are solid. *Top down* for a
plan view. The **Wall height** slider cuts the walls down so you can see into rooms from above — the
useful one for briefing. **Floor plan** toggles the source drawing laid flat underneath at exact scale,
which is how you check the 3D against the drawing. Click a room in the list to fly to it.

### Make a model from a new floor plan
```sh
# Java (full pipeline: image -> rooms, walls, scale, scene.json, 3D model)
javac -d /tmp/gl backend/src/com/gridlinescan/FloorplanTo3D.java
java -cp /tmp/gl com.gridlinescan.FloorplanTo3D input/real/your_plan.png \
     --ppm 48.9 --viewer --template frontend/viewer.template.html

# or rebuild a viewer from an existing scene.json, no JDK needed
node frontend/build-viewer.js output/your_plan.scene.json input/real/your_plan.png \
     output/your_plan.model.html "Your plan"
```
Run `--calib "2=16'x18'6\""` instead of `--ppm` to fit the scale from known room dimensions.

### Test a change without a browser
`dev-tools/harness.js` runs a generated model head-on under node with the DOM and the GPU stubbed but
**real three.js** underneath, so scene-graph and geometry errors surface immediately:
```sh
cd dev-tools && npm install three@0.128.0 && node harness.js ../output/apartment_2bed2bath_2d.model.html
```
It prints `RAN CLEAN` plus the mesh count and camera position, or the exception. This is what found
Fault 1. `dev-tools/render-preview.py` rasterises the scene to a PNG the same way `preview.png` was made.

---

## 4. Still true, still worth knowing

* **Dimensions are estimates.** Scale comes from `--ppm` or `--calib`, not survey. The panel says so, and
  the accuracy notes in each model list the specific caveats. Do not use this in place of official plans.
* Openings are not classified — doors, windows and cased openings are all just gaps in a wall.
* Wall height is a constant assumption (2.6 m), not measured.
* Rooms are split by pinching free space at doorways; an opening wider than `--door` merges two rooms.
* There is no ceiling, by design — you look into an open-topped model.

## 5. Worth doing next

1. **Classify openings** (door vs window vs cased) by gap width and by whether both sides are interior.
   Doors are what a fire crew needs marked, and the data to infer them is already in the wall mask.
2. **Responder overlay**, which is the original point of the project: drop entry/hazard/victim markers,
   draw a green approach zone and red entry arrows onto the model, export as a briefing PNG.
3. Wire this into the Gridline dispatch app (Spring Boot :3001) so a dispatcher can open the model for
   an address from the call panel.
4. The video-to-3D scan pipeline (separate work, see the earlier handoff) is still unfinished; this
   floor-plan path is the one that currently produces usable geometry.

---

# Addendum — v6.1: the realistic pass (Sep 19, 2026)

The model now renders as a furnished, daylit interior instead of a grey massing diagram, following the
marketing rendering for look and **the dimensioned floor plan for every dimension**. Nothing about the
geometry moved: walls are still the scanned rectangles, exactly where the drawing put them.

## How it is put together

Three pieces, so that realism is optional and reusable:

* **`frontend/realism.js`** — materials, furniture and lighting. Every texture is painted into a
  `<canvas>` at load time (oak boards with grain, carpet speckle, tile with grout, veined stone, the
  navy geometric rug), so there are still **no downloads of any kind**. Furniture is built from boxes,
  cylinders and spheres: beds with duvets and pillows, sofa, armchair, coffee table, TV unit, kitchen
  island with a sink, stools, counters with uppers, range, fridge, dishwasher, tub, shower with glass,
  toilets, vanities with mirrors, washer/dryer, wardrobes, plants, balcony railing.
* **`frontend/furnish/apartment_2bed2bath_2d.furnish.json`** — what goes where. It contains **no
  coordinates for furniture**. Each entry names a room in the scene JSON and anchors an item by rule:
  `{"t":"bed","wall":"n","along":0.55}` means *queen bed, against the north wall, 55% along it*. The
  viewer resolves that against the room's measured footprint at load time, so if the plan changes the
  furniture follows it.
* **`frontend/viewer.template.html`** — unchanged behaviour when no furnishing file is supplied.
  `FURNISHED` gates the finishes, the daylight rig and the painted-drywall walls; without it you get
  the original schematic with its colour-coded rooms and measuring grid.

## The one non-obvious problem worth remembering

Anchoring to a room's **bounding box** does not work here, because these rooms are L-shaped. The living
room's bbox spills into Bedroom 1, so "against the west wall" put the sofa inside the bedroom. The fix
is `anchorRect()`: rasterise the room's real floor rectangles at 10 cm and find the **largest rectangle
that is entirely floor** (largest-rectangle-in-histogram, row by row). That is the usable open area, and
everything is anchored to it. Placement went from roughly half the items in walls to all of them in
sensible spots.

## Rebuilding

```sh
node frontend/build-viewer.js output/apartment_2bed2bath_2d.scene.json \
     input/real/apartment_2bed2bath_2d.png output/apartment_2bed2bath_2d.model.html \
     "2 bed / 2 bath" frontend/furnish/apartment_2bed2bath_2d.furnish.json
```

Drop the last argument and you get the schematic version of the same plan. To furnish a different plan,
copy the furnish file, point `room` at that plan's room ids, and adjust `wall`/`along`.

## What to do next on the realism

1. **Openings still are not classified**, which is now the most visible gap: doors and windows are holes
   in the walls with no leaves, frames or glass. Classifying gaps by width (and whether both sides are
   interior) would let the viewer hang real doors and windows, which is the single biggest step left
   toward the rendering.
2. Baseboards and door casings — cheap geometry, large payoff.
3. Ceiling toggle with recessed downlights, for a lit interior in Walk mode.
4. The furniture builders are deliberately plain. Rounded edges on the upholstery and a cushion or two
   would carry most of the remaining distance.

---

# Addendum — v7: one file, two uploads, no doors (Sep 20, 2026)

## 1. Doors and fixtures removed

They were never doors, which is why they looked wrong. The plan drawing contains door swing
arcs, toilets, tubs, sinks and stair nosings as ink, exactly like walls, so the tracer picked
them up and they arrived as ~920 stair-step fragments a few centimetres long. Standing those up
at wall height put curved slabs across every doorway.

A real wall run is never that short, so `build()` now drops any wall rectangle whose **long side
is under 0.30 m**. On this plan that removes 922 of 1,027 rectangles and leaves 105 clean wall
runs — every arc and fixture outline gone, no real wall lost. It falls back to the unfiltered set
if a plan somehow consists only of short runs, so a strange drawing degrades instead of vanishing.
`extract.js` applies the same rule at extraction time via `minWallRunM`.

Openings are still just gaps: nothing is hung in them. That remains the honest description.

## 2. `output/gridline-studio.html` — the whole product in one file

Front end, extractor and renderer in a single 1.7 MB HTML file with **zero network requests**.
Copy it to any web host — GitHub Pages, S3, Netlify, a folder on a server — or open it from disk.
There is no backend to deploy and no server to keep running: the floor-plan pipeline was ported
from Java to `frontend/extract.js` and runs in the page. **Nothing is uploaded anywhere** — the
images are read with `FileReader` and processed in the tab, which is worth telling users, because
floor plans of real buildings are sensitive.

### The two inputs

1. **Floor plan (layout)** — required. Sets every dimension. Line drawing on a light background.
2. **Detail view (appearance)** — optional. Its dominant colours are sampled and used to tint the
   wood, carpet and wall finishes, and it stays pinned in the panel as a reference (click to enlarge).

### Scale

Dimensions are only as good as the scale. Either type **pixels per metre**, or type the **total
width of the plan** in feet or metres and it solves for the scale. If the metre sizes in the room
list look wrong, this is the only thing to fix — everything else follows from it.

### Room types are a guess, and correctable

With no hand-written furnishing file, `autoFurnish()` guesses from floor area: biggest space is the
living room, anything else over 85 sq ft is a bedroom, small rooms are baths (capped at one per
bedroom, because past that small spaces are closets and cupboards, not more toilets), then kitchen,
then utility. The guess sets the floor finish and the furniture, so every room carries a dropdown in
the room list to correct it, and the model rebuilds on change.

## 3. Build and test

```sh
node frontend/build-studio.js output/gridline-studio.html \
     output/apartment_2bed2bath_2d.scene.json input/real/apartment_2bed2bath_2d.png \
     frontend/furnish/apartment_2bed2bath_2d.furnish.json      # seed args optional

cd dev-tools && npm install three@0.128.0
node harness.js ../output/gridline-studio.html      # boots the page headlessly
node test-upload.js ../input/real/<plan>.png        # extract -> furnish -> decorate
```

`test-upload.js` is the one to run after touching the extractor: it checks that room rectangles
stay inside the plan, that meshes are actually produced, and that no furniture lands outside the
footprint. All four sample plans pass.

## 4. Two bugs the harness caught while building this

Both were the same fault as the original dark screen — a `let`/`const` read from above its own
declaration, which throws and takes the page down before the first frame. `PLAN_IMAGE_SRC` read
`PLAN_IMAGE`, and `activeFurnish()` read `USER_FURNISH`, from the boot path. **If you add state to
the studio, declare it in the state block near the top, not next to the code that uses it.** Run
`harness.js` before shipping; it catches this class of bug in one second.

## 5. Known limits

* Room splitting still struggles on large or busy drawings — `apartment_3dplans_2.png` yields 3
  rooms for a 26 m plan. The doorway-pinch radius is the thing to tune there.
* The palette tint is coarse: dominant colours, not per-surface matching.
* Openings are unclassified, so still no doors, windows or glass. Same next step as before.
