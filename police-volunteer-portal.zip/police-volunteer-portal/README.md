# Police Community Volunteer Portal

A Java Spring Boot website where community members can browse police-led volunteer opportunities and register, while authorized staff can publish new opportunities.

## Requirements

- Java 17 or newer
- Maven 3.9 or newer

## Project structure

Place the downloaded files in this structure:

```text
police-volunteer-portal/
├── pom.xml
└── src/
    └── main/
        ├── java/
        │   └── com/
        │       └── example/
        │           └── volunteerportal/
        │               └── VolunteerPortalApplication.java
        └── resources/
            └── static/
                └── index.html
```

## Run the website

From the directory containing `pom.xml`:

```bash
mvn spring-boot:run
```

Open [http://localhost:8080](http://localhost:8080).

The default demonstration admin key is:

```text
change-me
```

## Set a secure admin key

Do not use the default key outside local development.

macOS or Linux:

```bash
export VOLUNTEER_ADMIN_KEY="replace-with-a-long-random-secret"
mvn spring-boot:run -Dspring-boot.run.arguments="--volunteer.admin-key=$VOLUNTEER_ADMIN_KEY"
```

Windows PowerShell:

```powershell
$env:VOLUNTEER_ADMIN_KEY = "replace-with-a-long-random-secret"
mvn spring-boot:run "-Dspring-boot.run.arguments=--volunteer.admin-key=$env:VOLUNTEER_ADMIN_KEY"
```

Alternatively, create `src/main/resources/application.properties`:

```properties
volunteer.admin-key=${VOLUNTEER_ADMIN_KEY:change-me}
```

Then set the `VOLUNTEER_ADMIN_KEY` environment variable before starting the application.

## Included features

- Responsive community-facing opportunity cards
- Search and category filtering
- Volunteer registration form
- Capacity and duplicate-email checks
- Administrator opportunity publishing form
- Admin endpoint protected by a configurable key
- Server-side validation
- Sample opportunities on startup

## Important production notes

This starter stores opportunities and registrations in memory, so data resets whenever the server restarts. Before deploying it publicly:

1. Add a persistent database such as PostgreSQL.
2. Replace the shared admin key with authenticated staff accounts and roles.
3. Add HTTPS, CSRF protection, rate limiting, audit logs, backups, and a privacy policy.
4. Limit access to volunteer personal information and define a retention policy.
5. Add email confirmation and cancellation workflows if needed.
6. Have the responsible police agency review branding, wording, accessibility, legal notices, and data-handling requirements.
