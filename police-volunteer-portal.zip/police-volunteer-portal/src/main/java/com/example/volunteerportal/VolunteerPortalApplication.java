package com.example.volunteerportal;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@SpringBootApplication
public class VolunteerPortalApplication implements CommandLineRunner {
    private final VolunteerService service;

    public VolunteerPortalApplication(VolunteerService service) {
        this.service = service;
    }

    public static void main(String[] args) {
        SpringApplication.run(VolunteerPortalApplication.class, args);
    }

    @Override
    public void run(String... args) {
        if (!service.isEmpty()) return;

        service.create(new CreateOpportunityRequest(
                "Neighborhood Safety Walk",
                "Walk alongside community officers, note lighting or accessibility concerns, and share safety resources with residents.",
                "Neighborhood Outreach",
                "Westside Community Center",
                LocalDate.now().plusDays(14),
                LocalTime.of(18, 0),
                30,
                "community@police.gov"
        ));

        service.create(new CreateOpportunityRequest(
                "Youth Bicycle Safety Day",
                "Help fit helmets, guide families through activity stations, and support officers teaching bicycle safety skills.",
                "Youth Program",
                "Riverside Elementary School",
                LocalDate.now().plusDays(25),
                LocalTime.of(10, 0),
                24,
                "events@police.gov"
        ));
    }
}

@RestController
@RequestMapping("/api")
class VolunteerController {
    private final VolunteerService service;
    private final String adminKey;

    VolunteerController(VolunteerService service,
                        @Value("${volunteer.admin-key:change-me}") String adminKey) {
        this.service = service;
        this.adminKey = adminKey;
    }

    @GetMapping("/opportunities")
    List<OpportunityResponse> opportunities() {
        return service.findAll();
    }

    @PostMapping("/admin/opportunities")
    @ResponseStatus(HttpStatus.CREATED)
    OpportunityResponse createOpportunity(
            @RequestHeader(value = "X-Admin-Key", required = false) String suppliedKey,
            @Valid @RequestBody CreateOpportunityRequest request) {
        requireAdmin(suppliedKey);
        return service.create(request);
    }

    @PostMapping("/opportunities/{id}/register")
    @ResponseStatus(HttpStatus.CREATED)
    RegistrationResponse register(
            @PathVariable long id,
            @Valid @RequestBody RegistrationRequest request) {
        return service.register(id, request);
    }

    private void requireAdmin(String suppliedKey) {
        if (suppliedKey == null || !constantTimeEquals(adminKey, suppliedKey)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid admin key.");
        }
    }

    private boolean constantTimeEquals(String expected, String supplied) {
        if (expected.length() != supplied.length()) return false;
        int result = 0;
        for (int i = 0; i < expected.length(); i++) {
            result |= expected.charAt(i) ^ supplied.charAt(i);
        }
        return result == 0;
    }
}

@Service
class VolunteerService {
    private final AtomicLong opportunityIds = new AtomicLong();
    private final AtomicLong registrationIds = new AtomicLong();
    private final Map<Long, Opportunity> opportunities = new ConcurrentHashMap<>();
    private final Map<Long, List<Registration>> registrations = new ConcurrentHashMap<>();

    boolean isEmpty() {
        return opportunities.isEmpty();
    }

    List<OpportunityResponse> findAll() {
        return opportunities.values().stream()
                .filter(item -> !item.eventDate().isBefore(LocalDate.now()))
                .sorted(Comparator.comparing(Opportunity::eventDate)
                        .thenComparing(Opportunity::eventTime))
                .map(this::toResponse)
                .toList();
    }

    OpportunityResponse create(CreateOpportunityRequest request) {
        long id = opportunityIds.incrementAndGet();
        Opportunity opportunity = new Opportunity(
                id,
                clean(request.title()),
                clean(request.description()),
                clean(request.category()),
                clean(request.location()),
                request.eventDate(),
                request.eventTime(),
                request.capacity(),
                clean(request.contactEmail()).toLowerCase(Locale.ROOT)
        );
        opportunities.put(id, opportunity);
        registrations.put(id, new ArrayList<>());
        return toResponse(opportunity);
    }

    synchronized RegistrationResponse register(long opportunityId, RegistrationRequest request) {
        Opportunity opportunity = opportunities.get(opportunityId);
        if (opportunity == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Opportunity not found.");
        }
        if (opportunity.eventDate().isBefore(LocalDate.now())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Registration is closed for this opportunity.");
        }

        List<Registration> current = registrations.computeIfAbsent(opportunityId, ignored -> new ArrayList<>());
        if (current.size() >= opportunity.capacity()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "This opportunity is already full.");
        }

        String normalizedEmail = clean(request.email()).toLowerCase(Locale.ROOT);
        boolean duplicate = current.stream().anyMatch(item -> item.email().equalsIgnoreCase(normalizedEmail));
        if (duplicate) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "This email is already registered for the opportunity.");
        }

        Registration registration = new Registration(
                registrationIds.incrementAndGet(),
                opportunityId,
                clean(request.firstName()),
                clean(request.lastName()),
                normalizedEmail,
                clean(request.phone()),
                request.notes() == null ? "" : clean(request.notes())
        );
        current.add(registration);

        return new RegistrationResponse(
                registration.id(),
                opportunityId,
                opportunity.title(),
                "Registration received. The event contact may follow up with more information."
        );
    }

    private OpportunityResponse toResponse(Opportunity opportunity) {
        int registered = registrations.getOrDefault(opportunity.id(), List.of()).size();
        return new OpportunityResponse(
                opportunity.id(),
                opportunity.title(),
                opportunity.description(),
                opportunity.category(),
                opportunity.location(),
                opportunity.eventDate(),
                opportunity.eventTime(),
                opportunity.capacity(),
                registered,
                Math.max(0, opportunity.capacity() - registered),
                opportunity.contactEmail()
        );
    }

    private String clean(String value) {
        return value == null ? "" : value.trim();
    }
}

record Opportunity(
        long id,
        String title,
        String description,
        String category,
        String location,
        LocalDate eventDate,
        LocalTime eventTime,
        int capacity,
        String contactEmail
) {}

record Registration(
        long id,
        long opportunityId,
        String firstName,
        String lastName,
        String email,
        String phone,
        String notes
) {}

record CreateOpportunityRequest(
        @NotBlank @Size(max = 100) String title,
        @NotBlank @Size(max = 1000) String description,
        @NotBlank @Size(max = 50) String category,
        @NotBlank @Size(max = 120) String location,
        @NotNull @FutureOrPresent LocalDate eventDate,
        @NotNull LocalTime eventTime,
        @Min(1) @Max(10000) int capacity,
        @NotBlank @Email String contactEmail
) {}

record RegistrationRequest(
        @NotBlank @Size(max = 60) String firstName,
        @NotBlank @Size(max = 60) String lastName,
        @NotBlank @Email String email,
        @NotBlank @Size(max = 30) String phone,
        @Size(max = 500) String notes
) {}

record OpportunityResponse(
        long id,
        String title,
        String description,
        String category,
        String location,
        LocalDate eventDate,
        LocalTime eventTime,
        int capacity,
        int registeredCount,
        int spotsRemaining,
        String contactEmail
) {}

record RegistrationResponse(
        long registrationId,
        long opportunityId,
        String opportunityTitle,
        String message
) {}