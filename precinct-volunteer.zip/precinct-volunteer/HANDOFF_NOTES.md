# Handoff notes — Metro PD Community Volunteers

Notes for whoever (human or another Claude session) picks this up next.

## Session 5 update (latest)

The user asked for a simple admin **password** (like `adm1n`) rather than a key,
plus clear navigation between the public and admin pages. Done: default password
`adm1n` (`ADMIN_PASSWORD` env var, `X-Admin-Password` header,
`data/ADMIN_PASSWORD.txt`); a small per-address lockout after 10 wrong passwords
in 5 minutes (`requireAdmin` in the Java file); Enter-to-log-in and clearer error
messages in `admin.js`; nav links between the pages; consistent "GridLine"
branding. `server.js` (Node) was deleted since it used the old header. Anything
below that mentions the "admin key", `X-Admin-Key`, or Node as a fallback is
history and no longer applies.

---

## Session 4 update (latest)

**The Java back end is the primary back end again, and it has finally been
compiled and run.** This session's container had a JDK 21 (no `javac` launcher
on the PATH, but the `jdk.compiler` module is present, so
`java server/PrecinctVolunteerServer.java` and
`java -m jdk.compiler/com.sun.tools.javac.Main ...` both work). That resolved the
long-standing "never compiled" item from Sessions 1-3, so the Node detour is no
longer needed. `HANDOVER.md` has the summary of changes; the essentials:

- `server/PrecinctVolunteerServer.java` was rewritten to match the Node API
  (featured flag, PATCH, admin key file) and hardened (atomic sign-ups under one
  lock, duplicate-email 409, validation, body-size cap, atomic file writes,
  corrupt-file backup, seed-only-on-first-run). The JSON reader is now a real
  small parser, so the Session 2 concerns about the hand-rolled flat parser
  are gone.
- Tested with curl (all routes, negative cases, 40-way concurrent sign-up race,
  restart persistence) and a headless-Chromium click-through of both pages.
  `javac -Xlint:all` is clean; `-source 11` compiles.
- `public/admin.js` now consumes response bodies it used to ignore (harmless, but
  Chromium reported them as canceled requests against the Java server).
- `server.js` remains as an optional fallback; it lacks the Session 4 checks.
- Sessions below are history. Where they say Node is primary, that is superseded.

Suggested next steps: real admin accounts, HTTPS via reverse proxy, rate limiting
on `/api/register`, a real database if this outgrows two JSON files, and actual
email/SMS if a provider is available.

---

## Session 3 update (superseded by Session 4)

The user reported three concrete problems plus a design request:

1. "It does not connect with the front main page."
2. "I don't know the admin key."
3. Wanted a way to push prompts for people to join events.
4. Wanted the same visual design as their other project, "Gridline"
   (a dark, tactical dispatch-console UI — dark navy/near-black surfaces,
   blue accent, IBM Plex Sans, thin hairline borders, tinted status colors).

### Root cause of #1, and the decision to switch off Java

Sessions 1 and 2 both flagged, in bold, that `PrecinctVolunteerServer.java`
had never been run through a real `javac` — no JDK was available in either
build environment, and this container still doesn't have one (`apt-get
install openjdk-*-jdk` still 403s with no network). Given that the exact
symptom the user hit ("frontend doesn't connect") is precisely what you'd
see if the backend never started, and given two sessions in a row couldn't
prove the Java file compiles, I made the call to **port the backend to
Node.js** (`server.js`, same directory, zero dependencies — just `http` and
`fs` from the standard library) rather than attempt a third unverified fix.

Unlike the Java file, `server.js` has actually been started and exercised in
this session: health check, event list/create/patch/delete, registration
(including the "already full" 409 case), admin auth (missing key, wrong key,
right key), the OPTIONS CORS preflight, and static file serving (including a
path-traversal probe, which correctly 404s) all ran successfully against a
live instance before this was handed back. Node is also far more commonly
pre-installed than a full JDK, which should remove the "can't get it running
at all" failure mode this project has hit twice now.

The original Java file is kept at `server/PrecinctVolunteerServer.java` for
reference/comparison, but `server.js` is now the primary, documented way to
run this app. If a future session or the user gets access to a real JDK and
wants to go back to Java, the Node file is a faithful enough reference for
the API contract that porting back should be mechanical.

One behavior change from the Java version: persistence now uses
`JSON.stringify`/`JSON.parse` instead of the hand-rolled `Json` class, so the
whole "custom parser might mishandle embedded quotes/braces" risk that
sessions 1–2 spent real effort de-risking (Python port + 20 adversarial test
cases) is moot — it's just real JSON now.

### #2 — admin key

The key was already documented (default `precinct-admin-2026`, override via
`ADMIN_KEY`), just easy to miss. `server.js` now also writes it to
`data/ADMIN_KEY.txt` on every startup, and the admin login screen itself
tells you where to look. No functional change otherwise.

### #3 — pushing prompts for people to join events

There's no outbound email/SMS in this project (no mail-server credentials,
and no network access in the environment that built it, so nothing on that
front could have been tested anyway). Implemented instead, as the most
useful thing that's actually deliverable and testable:

- **`featured` flag on events** (new field, `PATCH /api/events/{id}` with
  `{"featured": true}`). Featured + still-open opportunities show up in a
  highlighted "Urgently need volunteers" banner at the top of the public
  page.
- **"Copy invite" button** in the admin console per opportunity, which
  builds a formatted email/text draft (subject, event details, live sign-up
  link) and copies it to the clipboard, for staff to paste into whatever
  they already use to reach volunteers.

If the user later wants actual outbound email/SMS (not just a copyable
draft), that needs real provider credentials (e.g. an SMTP relay or a
service like SendGrid/Twilio) that aren't available in this build
environment — flagging as a good next step if they have such a service.

### #4 — Gridline design port

Pulled the design tokens straight from
`gridline-fullstack/frontend/src/styles.css` and `components/TopNav.jsx`:
near-black backgrounds (`#05070b`), dark card surfaces (`#0e1420`/`#131a28`),
a blue accent (`#3b7cf6`), tinted status colors (green/red/amber), IBM Plex
Sans/Mono, 8px-ish border radii, 1px hairline borders, and a small square
badge-style logo mark (Gridline uses a "911" square; this uses a "PD"
square in the same style). All class names in `styles.css` are unchanged
from the previous version, so `main.js`/`admin.js` needed no structural
changes for the reskin — only additive JS for the new spotlight/feature/
invite UI.

### Still true from earlier sessions

- **Concurrency correctness of `data/*.json` writes**: `server.js` now
  serializes writes through a promise chain (`saveQueue`) instead of Java's
  `synchronized`, which has the same effect — concurrent saves are queued,
  not interleaved.
- **Admin auth is still a shared secret, not real accounts.** Same
  upgrade path noted before (a `User` model + real login) still applies.
- **No HTTPS, no pagination, no real database** — same caveats as before,
  now just documented against `server.js` instead of the Java file.

---

## Session 2 notes (prior)

Picked up from Session 1's handoff. This container still has no `javac` and
no network access (`apt-get install openjdk-21-jdk-headless` fails with a
403 — confirmed again, plus checked for any bundled alternative compiler
(ECJ, tools.jar) anywhere on the image: none exists). **So the #1 open item
from Session 1 — actually compiling this — is still unverified by a real
compiler.** What was done instead, to close as much of that gap as possible:

1. **Ported the two hand-rolled JSON routines (`Json.parseFlatObject`,
   `Json.splitTopLevelObjects`) to Python, line-for-line, and ran 20
   adversarial test cases** against them: braces/quotes/newlines/backslashes
   embedded in free-text fields (the realistic failure mode for a hand-rolled
   parser), empty values, malformed input, unicode. All 20 passed.
2. **Did a full second manual read-through of the Java file, line by line**,
   and found and fixed one real bug: OPTIONS preflight responses never
   closed the exchange. Fixed by adding `ex.close()`.
3. **Hardened concurrent writes**: `saveEvents()`, `saveRegistrations()`, and
   `writeFile()` made `synchronized`.
4. **Fixed known limitation #8** from Session 1: the admin category dropdown
   is now populated by merging a default curated list with real categories.
5. Re-ran `node --check` on both `main.js` and `admin.js`, and the
   brace/paren balance check on the Java file.

**Still true, and still the most important next step for whoever has an
actual JDK available:** the `javac`/`java` compile-and-run cycle was never
completed. (Session 3: this is now moot for day-to-day use since the primary
backend is `server.js`, but the Java file is kept for reference and this
would still apply if someone wants to revive it.)

---

## Session 1 notes (original)

## What's built and working

A complete, runnable full-stack app:

- **Backend**: `server/PrecinctVolunteerServer.java` — single file, pure JDK
  (`com.sun.net.httpserver`), no Maven/Gradle/external libraries.
- **Frontend**: `public/index.html` + `main.js` (public browse/register page),
  `public/admin.html` + `admin.js` (admin console gated by a shared admin
  key), `public/styles.css` (shared design — see Session 3 for the current
  Gridline-matched version; originally a navy + brass "precinct bulletin
  board" look).
- Five seed opportunities are auto-created on first run so the page isn't
  empty (only if `data/events.json` doesn't already exist / is empty).

## Key design decisions (and why)

- **No frameworks/dependencies on either side.** Optimized for "clones and
  runs anywhere" over production-framework polish.
- **JSON files instead of a database.** Zero setup; fine for a demo/small
  precinct, not for concurrent multi-instance deployment.
- **Single shared admin key** (`X-Admin-Key` header) rather than real user
  accounts. Simplest thing that demonstrates "admin vs public" access
  control. Flagged clearly as something to replace before real deployment.
- **Same-origin serving.** The backend serves the static frontend itself, so
  the browser never has to deal with CORS in normal use. Permissive CORS
  headers are still sent in case the frontend is ever split out.

## Known limitations / good next steps

1. ~~Not compiled/tested yet~~ — **resolved in Session 3** by switching the
   primary backend to Node.js and running it end-to-end.
2. **Concurrency correctness of `data/*.json` writes**: each save does a
   full file rewrite; there's no file locking across separate processes.
   Fine for one server instance with moderate traffic; would need real
   storage (SQLite/Postgres) for anything more serious.
3. **Admin auth is a shared secret, not real accounts.** No password
   hashing, no per-admin audit trail. Upgrade path: add a `User` model, real
   login, and record `createdBy` on events.
4. **No real outbound email/SMS** for invites — see Session 3's "#3" above;
   the "Copy invite" button produces a draft, it doesn't send anything.
5. **No HTTPS.** Meant for local/dev use or sitting behind a reverse proxy
   (nginx/Caddy) that terminates TLS in production.
6. **No pagination** on `/api/events` or `/api/registrations` — fine at
   small scale, would need it for a large multi-precinct deployment.
7. **The JSON persistence is intentionally simple** (flat event/registration
   objects). If a future feature needs deeply nested data, a real database
   is a better fit than hand-rolled file I/O.

## File map

```
precinct-volunteer/
├── server.js                             backend (Node, primary — see Session 3)
├── server/PrecinctVolunteerServer.java   original Java backend, kept for reference
├── public/index.html                     public page markup
├── public/main.js                        public page logic (fetch, render, register, spotlight)
├── public/admin.html                     admin console markup
├── public/admin.js                       admin console logic (auth, CRUD, feature, invite, sign-ups)
├── public/styles.css                     shared design system (Gridline-matched)
├── data/                                 auto-generated JSON "database" + ADMIN_KEY.txt
├── README.md                             setup + run + API reference
└── HANDOFF_NOTES.md                      this file
```
