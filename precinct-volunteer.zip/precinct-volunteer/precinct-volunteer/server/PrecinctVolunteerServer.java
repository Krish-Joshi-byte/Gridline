import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;

/**
 * Metro PD Community Volunteers — backend server.
 *
 * Pure JDK, zero external dependencies (uses com.sun.net.httpserver.HttpServer,
 * which ships with every standard JDK). Compiles and runs with just:
 *   javac PrecinctVolunteerServer.java
 *   java PrecinctVolunteerServer
 *
 * Data model:
 *   Event        - a volunteer opportunity the admin publishes
 *   Registration - a community member signing up for an Event
 *
 * Persistence: on every write, the full in-memory state is flushed to
 * ./data/events.json and ./data/registrations.json (relative to the working
 * directory the server is launched from). On startup, existing files are
 * loaded back in. This is intentionally simple (no real database) — see
 * HANDOFF_NOTES.md for how to swap in something more robust later.
 *
 * Admin auth: a single shared-secret key (see ADMIN_KEY below), sent by the
 * admin frontend as the "X-Admin-Key" request header. This is intentionally
 * minimal for a first version — see HANDOFF_NOTES.md for upgrade paths.
 */
public class PrecinctVolunteerServer {

    // ---- Configuration -----------------------------------------------------

    static final int PORT = intFromEnv("PORT", 8080);
    static final String ADMIN_KEY = System.getenv().getOrDefault("ADMIN_KEY", "precinct-admin-2026");
    static final Path DATA_DIR = Paths.get("data");
    static final Path EVENTS_FILE = DATA_DIR.resolve("events.json");
    static final Path REGISTRATIONS_FILE = DATA_DIR.resolve("registrations.json");
    static final Path PUBLIC_DIR = Paths.get("public");

    static int intFromEnv(String name, int def) {
        String v = System.getenv(name);
        if (v == null) return def;
        try { return Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return def; }
    }

    // ---- In-memory state -----------------------------------------------------

    static final Map<String, Event> events = new ConcurrentHashMap<>();
    static final List<String> eventOrder = new CopyOnWriteArrayList<>(); // preserves creation order
    static final List<Registration> registrations = new CopyOnWriteArrayList<>();

    public static void main(String[] args) throws IOException {
        Files.createDirectories(DATA_DIR);
        loadState();
        if (events.isEmpty()) {
            seedSampleData();
            saveEvents();
        }

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/api/health", withCors(PrecinctVolunteerServer::handleHealth));
        server.createContext("/api/events", withCors(PrecinctVolunteerServer::handleEvents));
        server.createContext("/api/register", withCors(PrecinctVolunteerServer::handleRegister));
        server.createContext("/api/registrations", withCors(PrecinctVolunteerServer::handleRegistrations));
        server.createContext("/", withCors(PrecinctVolunteerServer::handleStatic));
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();

        System.out.println("=================================================");
        System.out.println(" Metro PD Community Volunteers server is running");
        System.out.println(" http://localhost:" + PORT);
        System.out.println(" Admin key: " + ADMIN_KEY + "  (set ADMIN_KEY env var to change)");
        System.out.println("=================================================");
    }

    // ---- Models -----------------------------------------------------------

    static class Event {
        String id, title, description, date, time, location, category;
        int capacity;

        Event(String id, String title, String description, String date, String time,
              String location, String category, int capacity) {
            this.id = id; this.title = title; this.description = description;
            this.date = date; this.time = time; this.location = location;
            this.category = category; this.capacity = capacity;
        }

        String toJson() {
            int registered = countRegistrationsFor(id);
            int remaining = Math.max(0, capacity - registered);
            StringBuilder sb = new StringBuilder("{");
            sb.append("\"id\":\"").append(Json.esc(id)).append("\",");
            sb.append("\"title\":\"").append(Json.esc(title)).append("\",");
            sb.append("\"description\":\"").append(Json.esc(description)).append("\",");
            sb.append("\"date\":\"").append(Json.esc(date)).append("\",");
            sb.append("\"time\":\"").append(Json.esc(time)).append("\",");
            sb.append("\"location\":\"").append(Json.esc(location)).append("\",");
            sb.append("\"category\":\"").append(Json.esc(category)).append("\",");
            sb.append("\"capacity\":").append(capacity).append(",");
            sb.append("\"registered\":").append(registered).append(",");
            sb.append("\"remaining\":").append(remaining);
            sb.append("}");
            return sb.toString();
        }
    }

    static class Registration {
        String id, eventId, name, email, phone, notes, createdAt;

        Registration(String id, String eventId, String name, String email, String phone,
                     String notes, String createdAt) {
            this.id = id; this.eventId = eventId; this.name = name; this.email = email;
            this.phone = phone; this.notes = notes; this.createdAt = createdAt;
        }

        String toJson() {
            StringBuilder sb = new StringBuilder("{");
            sb.append("\"id\":\"").append(Json.esc(id)).append("\",");
            sb.append("\"eventId\":\"").append(Json.esc(eventId)).append("\",");
            sb.append("\"name\":\"").append(Json.esc(name)).append("\",");
            sb.append("\"email\":\"").append(Json.esc(email)).append("\",");
            sb.append("\"phone\":\"").append(Json.esc(phone)).append("\",");
            sb.append("\"notes\":\"").append(Json.esc(notes)).append("\",");
            sb.append("\"createdAt\":\"").append(Json.esc(createdAt)).append("\"");
            sb.append("}");
            return sb.toString();
        }
    }

    static int countRegistrationsFor(String eventId) {
        int c = 0;
        for (Registration r : registrations) if (r.eventId.equals(eventId)) c++;
        return c;
    }

    // ---- Route handlers -----------------------------------------------------

    static void handleHealth(HttpExchange ex) throws IOException {
        sendJson(ex, 200, "{\"status\":\"ok\"}");
    }

    static void handleEvents(HttpExchange ex) throws IOException {
        String method = ex.getRequestMethod();
        String path = ex.getRequestURI().getPath(); // /api/events or /api/events/{id}
        String remainder = path.length() > "/api/events".length()
                ? path.substring("/api/events".length()).replaceAll("^/", "")
                : "";

        if (method.equals("GET") && remainder.isEmpty()) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < eventOrder.size(); i++) {
                Event e = events.get(eventOrder.get(i));
                if (e == null) continue;
                if (sb.length() > 1) sb.append(",");
                sb.append(e.toJson());
            }
            sb.append("]");
            sendJson(ex, 200, sb.toString());
            return;
        }

        if (method.equals("POST") && remainder.isEmpty()) {
            if (!isAdmin(ex)) { sendJson(ex, 401, err("Admin key required.")); return; }
            Map<String, String> body = Json.parseFlatObject(readBody(ex));
            String title = body.getOrDefault("title", "").trim();
            String description = body.getOrDefault("description", "").trim();
            String date = body.getOrDefault("date", "").trim();
            String time = body.getOrDefault("time", "").trim();
            String location = body.getOrDefault("location", "").trim();
            String category = body.getOrDefault("category", "General").trim();
            int capacity;
            try { capacity = Integer.parseInt(body.getOrDefault("capacity", "0").trim()); }
            catch (NumberFormatException e) { capacity = 0; }

            if (title.isEmpty() || date.isEmpty() || capacity <= 0) {
                sendJson(ex, 400, err("Title, date, and a capacity greater than 0 are required."));
                return;
            }

            String id = newId("evt");
            Event event = new Event(id, title, description, date, time, location, category, capacity);
            events.put(id, event);
            eventOrder.add(id);
            saveEvents();
            sendJson(ex, 201, event.toJson());
            return;
        }

        if (method.equals("DELETE") && !remainder.isEmpty()) {
            if (!isAdmin(ex)) { sendJson(ex, 401, err("Admin key required.")); return; }
            String id = remainder;
            if (events.remove(id) != null) {
                eventOrder.remove(id);
                registrations.removeIf(r -> r.eventId.equals(id));
                saveEvents();
                saveRegistrations();
                sendJson(ex, 200, "{\"deleted\":\"" + Json.esc(id) + "\"}");
            } else {
                sendJson(ex, 404, err("No opportunity found with that id."));
            }
            return;
        }

        sendJson(ex, 405, err("Method not allowed on this endpoint."));
    }

    static void handleRegister(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("POST")) {
            sendJson(ex, 405, err("Use POST to register.")); return;
        }
        Map<String, String> body = Json.parseFlatObject(readBody(ex));
        String eventId = body.getOrDefault("eventId", "").trim();
        String name = body.getOrDefault("name", "").trim();
        String email = body.getOrDefault("email", "").trim();
        String phone = body.getOrDefault("phone", "").trim();
        String notes = body.getOrDefault("notes", "").trim();

        if (eventId.isEmpty() || name.isEmpty() || email.isEmpty()) {
            sendJson(ex, 400, err("Name, email, and an opportunity are required.")); return;
        }
        Event event = events.get(eventId);
        if (event == null) { sendJson(ex, 404, err("That opportunity is no longer available.")); return; }

        int registered = countRegistrationsFor(eventId);
        if (registered >= event.capacity) {
            sendJson(ex, 409, err("That opportunity is already full.")); return;
        }

        Registration r = new Registration(newId("reg"), eventId, name, email, phone, notes,
                Instant.now().toString());
        registrations.add(r);
        saveRegistrations();
        sendJson(ex, 201, r.toJson());
    }

    static void handleRegistrations(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("GET")) {
            sendJson(ex, 405, err("Method not allowed.")); return;
        }
        if (!isAdmin(ex)) { sendJson(ex, 401, err("Admin key required.")); return; }

        String query = ex.getRequestURI().getQuery();
        String filterEventId = null;
        if (query != null) {
            for (String part : query.split("&")) {
                String[] kv = part.split("=", 2);
                if (kv.length == 2 && kv[0].equals("eventId")) filterEventId = urlDecode(kv[1]);
            }
        }
        StringBuilder sb = new StringBuilder("[");
        for (Registration r : registrations) {
            if (filterEventId != null && !r.eventId.equals(filterEventId)) continue;
            if (sb.length() > 1) sb.append(",");
            sb.append(r.toJson());
        }
        sb.append("]");
        sendJson(ex, 200, sb.toString());
    }

    static String urlDecode(String s) {
        try { return java.net.URLDecoder.decode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    // ---- Static file serving ------------------------------------------------

    static void handleStatic(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("GET")) { sendJson(ex, 405, err("Method not allowed.")); return; }
        String reqPath = ex.getRequestURI().getPath();
        if (reqPath.equals("/")) reqPath = "/index.html";

        Path target = PUBLIC_DIR.resolve(reqPath.substring(1)).normalize();
        if (!target.startsWith(PUBLIC_DIR) || !Files.exists(target) || Files.isDirectory(target)) {
            byte[] notFound = "404 — page not found.".getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
            ex.sendResponseHeaders(404, notFound.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(notFound); }
            return;
        }

        byte[] data = Files.readAllBytes(target);
        ex.getResponseHeaders().set("Content-Type", contentType(target.toString()));
        ex.sendResponseHeaders(200, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    static String contentType(String path) {
        if (path.endsWith(".html")) return "text/html; charset=utf-8";
        if (path.endsWith(".css")) return "text/css; charset=utf-8";
        if (path.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (path.endsWith(".json")) return "application/json; charset=utf-8";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    // ---- Helpers -----------------------------------------------------------

    static boolean isAdmin(HttpExchange ex) {
        String key = ex.getRequestHeaders().getFirst("X-Admin-Key");
        return key != null && key.equals(ADMIN_KEY);
    }

    static String err(String message) {
        return "{\"error\":\"" + Json.esc(message) + "\"}";
    }

    static String newId(String prefix) {
        return prefix + "_" + Long.toHexString(System.nanoTime()) + Integer.toHexString(new Random().nextInt(0xFFFF));
    }

    static String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    static void sendJson(HttpExchange ex, int status, String json) throws IOException {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    /** Wraps a handler with permissive CORS headers and OPTIONS preflight support. */
    static HttpHandler withCors(HttpHandler inner) {
        return ex -> {
            ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
            ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, X-Admin-Key");
            if (ex.getRequestMethod().equals("OPTIONS")) {
                ex.sendResponseHeaders(204, -1);
                ex.close(); // no body follows; must close explicitly or the exchange never completes
                return;
            }
            try {
                inner.handle(ex);
            } catch (Exception e) {
                e.printStackTrace();
                try { sendJson(ex, 500, err("Unexpected server error.")); } catch (IOException ignored) {}
            }
        };
    }

    // ---- Persistence ---------------------------------------------------------

    // synchronized: several request threads can trigger a save at once (the
    // executor pool has 8 threads); without this two full-file rewrites could
    // interleave and corrupt events.json / registrations.json.
    static synchronized void saveEvents() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < eventOrder.size(); i++) {
            Event e = events.get(eventOrder.get(i));
            if (e == null) continue;
            if (sb.length() > 1) sb.append(",");
            sb.append(e.toJson());
        }
        sb.append("]");
        writeFile(EVENTS_FILE, sb.toString());
    }

    static synchronized void saveRegistrations() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < registrations.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(registrations.get(i).toJson());
        }
        sb.append("]");
        writeFile(REGISTRATIONS_FILE, sb.toString());
    }

    static synchronized void writeFile(Path path, String content) {
        try {
            Files.write(path, content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Failed to write " + path + ": " + e.getMessage());
        }
    }

    static void loadState() {
        try {
            if (Files.exists(EVENTS_FILE)) {
                String content = new String(Files.readAllBytes(EVENTS_FILE), StandardCharsets.UTF_8);
                for (String obj : Json.splitTopLevelObjects(content)) {
                    Map<String, String> m = Json.parseFlatObject(obj);
                    Event e = new Event(
                            m.getOrDefault("id", newId("evt")),
                            m.getOrDefault("title", ""),
                            m.getOrDefault("description", ""),
                            m.getOrDefault("date", ""),
                            m.getOrDefault("time", ""),
                            m.getOrDefault("location", ""),
                            m.getOrDefault("category", "General"),
                            parseIntSafe(m.get("capacity"), 0)
                    );
                    events.put(e.id, e);
                    eventOrder.add(e.id);
                }
            }
            if (Files.exists(REGISTRATIONS_FILE)) {
                String content = new String(Files.readAllBytes(REGISTRATIONS_FILE), StandardCharsets.UTF_8);
                for (String obj : Json.splitTopLevelObjects(content)) {
                    Map<String, String> m = Json.parseFlatObject(obj);
                    registrations.add(new Registration(
                            m.getOrDefault("id", newId("reg")),
                            m.getOrDefault("eventId", ""),
                            m.getOrDefault("name", ""),
                            m.getOrDefault("email", ""),
                            m.getOrDefault("phone", ""),
                            m.getOrDefault("notes", ""),
                            m.getOrDefault("createdAt", Instant.now().toString())
                    ));
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to load persisted state: " + e.getMessage());
        }
    }

    static int parseIntSafe(String s, int def) {
        if (s == null) return def;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }

    static void seedSampleData() {
        String[][] seed = {
                {"National Night Out Booth", "Staff the department's community booth: hand out safety literature, run the child ID kit table, and answer questions from neighbors.", "2026-10-06", "17:00", "Riverside Park Pavilion", "Community Outreach", "8"},
                {"Neighborhood Watch Kickoff", "Help set up chairs, sign in attendees, and hand out starter packets for a new Neighborhood Watch group's first meeting.", "2026-10-14", "18:30", "Precinct 3 Community Room", "Neighborhood Safety", "6"},
                {"Bike Rodeo Safety Course", "Assist officers running a youth bicycle safety course: helmet fitting, obstacle course setup, and course marshaling.", "2026-10-18", "10:00", "Lincoln Elementary Parking Lot", "Youth Programs", "12"},
                {"Senior Vial of Life Deliveries", "Ride along with a volunteer coordinator to deliver Vial of Life kits to seniors who requested them.", "2026-10-25", "09:00", "Meet at Precinct 1", "Community Outreach", "5"},
                {"Records Room Filing Support", "Help the records division scan and file archived paperwork. No law-enforcement background needed, just attention to detail.", "2026-11-02", "13:00", "Police Headquarters, Records Division", "Administrative Support", "3"}
        };
        for (String[] s : seed) {
            String id = newId("evt");
            events.put(id, new Event(id, s[0], s[1], s[2], s[3], s[4], s[5], Integer.parseInt(s[6])));
            eventOrder.add(id);
        }
    }

    // ---- Minimal JSON utility (no external dependencies) ---------------------

    static class Json {
        static String esc(String s) {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder();
            for (char c : s.toCharArray()) {
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            return sb.toString();
        }

        /** Parses a single flat JSON object (string/number values only) into a String map. */
        static Map<String, String> parseFlatObject(String json) {
            Map<String, String> map = new LinkedHashMap<>();
            if (json == null) return map;
            int i = 0, n = json.length();
            while (i < n && json.charAt(i) != '{') i++;
            i++;
            while (i < n) {
                while (i < n && (Character.isWhitespace(json.charAt(i)) || json.charAt(i) == ',')) i++;
                if (i >= n || json.charAt(i) == '}') break;
                if (json.charAt(i) != '"') break; // malformed; bail gracefully
                i++;
                StringBuilder key = new StringBuilder();
                while (i < n && json.charAt(i) != '"') {
                    char c = json.charAt(i);
                    if (c == '\\' && i + 1 < n) { i++; key.append(unescape(json.charAt(i))); }
                    else key.append(c);
                    i++;
                }
                i++; // closing quote
                while (i < n && (Character.isWhitespace(json.charAt(i)) || json.charAt(i) == ':')) i++;
                String value;
                if (i < n && json.charAt(i) == '"') {
                    i++;
                    StringBuilder val = new StringBuilder();
                    while (i < n && json.charAt(i) != '"') {
                        char c = json.charAt(i);
                        if (c == '\\' && i + 1 < n) { i++; val.append(unescape(json.charAt(i))); }
                        else val.append(c);
                        i++;
                    }
                    i++; // closing quote
                    value = val.toString();
                } else {
                    int start = i;
                    while (i < n && json.charAt(i) != ',' && json.charAt(i) != '}') i++;
                    value = json.substring(start, i).trim();
                }
                map.put(key.toString(), value);
            }
            return map;
        }

        static char unescape(char c) {
            switch (c) {
                case 'n': return '\n';
                case 't': return '\t';
                case 'r': return '\r';
                case '"': return '"';
                case '\\': return '\\';
                case '/': return '/';
                default: return c;
            }
        }

        /** Splits a top-level JSON array's text into the raw text of each object element,
         *  correctly ignoring braces that appear inside string values. */
        static List<String> splitTopLevelObjects(String s) {
            List<String> result = new ArrayList<>();
            int depth = 0, start = -1;
            boolean inStr = false, esc = false;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (inStr) {
                    if (esc) esc = false;
                    else if (c == '\\') esc = true;
                    else if (c == '"') inStr = false;
                    continue;
                }
                if (c == '"') { inStr = true; continue; }
                if (c == '{') { if (depth == 0) start = i; depth++; }
                else if (c == '}') { depth--; if (depth == 0 && start >= 0) result.add(s.substring(start, i + 1)); }
            }
            return result;
        }
    }
}
