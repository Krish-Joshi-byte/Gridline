// Metro PD Community Volunteers — backend server (Node.js, zero dependencies)
//
// Why Node instead of the old Java version: the Java file
// (server/PrecinctVolunteerServer.java, still included for reference) was
// hand-rolled against com.sun.net.httpserver and, across two prior sessions,
// was never actually run through a real `javac` — no JDK was available in
// either build environment. That's the most likely reason the frontend
// couldn't reach it: if the backend never started, every fetch() call on the
// public and admin pages fails, which is exactly the symptom described.
//
// This file is a line-for-line port of the same API surface using only
// Node's built-in `http`/`fs` modules (no npm install, no dependencies), and
// it HAS been started, exercised end-to-end, and curled against every route
// in the environment that built it. Node is also far more likely to already
// be installed than a full JDK, which should remove the "can't get it
// running at all" problem entirely.
//
// Run:
//   node server.js
// from the project root (the folder this file is in).

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

// ---- Configuration ---------------------------------------------------------

const PORT = parseInt(process.env.PORT || "8080", 10);
const ADMIN_KEY = process.env.ADMIN_KEY || "precinct-admin-2026";
const DATA_DIR = path.join(__dirname, "data");
const EVENTS_FILE = path.join(DATA_DIR, "events.json");
const REGISTRATIONS_FILE = path.join(DATA_DIR, "registrations.json");
const ADMIN_KEY_FILE = path.join(DATA_DIR, "ADMIN_KEY.txt");
const PUBLIC_DIR = path.join(__dirname, "public");

// ---- In-memory state --------------------------------------------------------

let events = [];        // array of Event, insertion order preserved
let registrations = [];  // array of Registration

function newId(prefix) {
  return `${prefix}_${Date.now().toString(36)}${crypto.randomBytes(4).toString("hex")}`;
}

function countRegistrationsFor(eventId) {
  return registrations.filter((r) => r.eventId === eventId).length;
}

function eventToJson(e) {
  const registered = countRegistrationsFor(e.id);
  const remaining = Math.max(0, e.capacity - registered);
  return { ...e, registered, remaining };
}

// ---- Persistence -------------------------------------------------------------
// Uses real JSON.parse/JSON.stringify (no hand-rolled parser), so the
// braces/quotes/unicode edge cases that worried the previous session's
// Python port of the Java parser simply don't apply here.

let saveQueue = Promise.resolve(); // serializes writes so concurrent saves can't interleave

function persist(file, data) {
  saveQueue = saveQueue
    .then(() => fs.promises.writeFile(file, JSON.stringify(data, null, 2), "utf8"))
    .catch((err) => console.error(`Failed to write ${file}:`, err.message));
  return saveQueue;
}

function saveEvents() { return persist(EVENTS_FILE, events); }
function saveRegistrations() { return persist(REGISTRATIONS_FILE, registrations); }

function loadState() {
  try {
    if (fs.existsSync(EVENTS_FILE)) {
      events = JSON.parse(fs.readFileSync(EVENTS_FILE, "utf8"));
    }
  } catch (err) {
    console.error("Failed to load events.json:", err.message);
    events = [];
  }
  try {
    if (fs.existsSync(REGISTRATIONS_FILE)) {
      registrations = JSON.parse(fs.readFileSync(REGISTRATIONS_FILE, "utf8"));
    }
  } catch (err) {
    console.error("Failed to load registrations.json:", err.message);
    registrations = [];
  }
}

function seedSampleData() {
  const seed = [
    ["National Night Out Booth", "Staff the department's community booth: hand out safety literature, run the child ID kit table, and answer questions from neighbors.", "2026-10-06", "17:00", "Riverside Park Pavilion", "Community Outreach", 8, true],
    ["Neighborhood Watch Kickoff", "Help set up chairs, sign in attendees, and hand out starter packets for a new Neighborhood Watch group's first meeting.", "2026-10-14", "18:30", "Precinct 3 Community Room", "Neighborhood Safety", 6, false],
    ["Bike Rodeo Safety Course", "Assist officers running a youth bicycle safety course: helmet fitting, obstacle course setup, and course marshaling.", "2026-10-18", "10:00", "Lincoln Elementary Parking Lot", "Youth Programs", 12, false],
    ["Senior Vial of Life Deliveries", "Ride along with a volunteer coordinator to deliver Vial of Life kits to seniors who requested them.", "2026-10-25", "09:00", "Meet at Precinct 1", "Community Outreach", 5, true],
    ["Records Room Filing Support", "Help the records division scan and file archived paperwork. No law-enforcement background needed, just attention to detail.", "2026-11-02", "13:00", "Police Headquarters, Records Division", "Administrative Support", 3, false],
  ];
  events = seed.map(([title, description, date, time, location, category, capacity, featured]) => ({
    id: newId("evt"), title, description, date, time, location, category, capacity, featured,
  }));
}

// ---- HTTP helpers -------------------------------------------------------------

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function err(message) {
  return { error: message };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (e) {
        resolve({});
      }
    });
    req.on("error", reject);
  });
}

function isAdmin(req) {
  const key = req.headers["x-admin-key"];
  return typeof key === "string" && key === ADMIN_KEY;
}

const CONTENT_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

function serveStatic(req, res, pathname) {
  if (req.method !== "GET") return sendJson(res, 405, err("Method not allowed."));
  let reqPath = pathname === "/" ? "/index.html" : pathname;
  const target = path.normalize(path.join(PUBLIC_DIR, reqPath));
  if (!target.startsWith(PUBLIC_DIR) || !fs.existsSync(target) || fs.statSync(target).isDirectory()) {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("404 — page not found.");
    return;
  }
  const data = fs.readFileSync(target);
  const ext = path.extname(target);
  res.writeHead(200, { "Content-Type": CONTENT_TYPES[ext] || "application/octet-stream" });
  res.end(data);
}

// ---- Route handlers -------------------------------------------------------------

function handleHealth(req, res) {
  sendJson(res, 200, { status: "ok" });
}

async function handleEvents(req, res, remainder) {
  if (req.method === "GET" && remainder === "") {
    const sorted = [...events];
    return sendJson(res, 200, sorted.map(eventToJson));
  }

  if (req.method === "POST" && remainder === "") {
    if (!isAdmin(req)) return sendJson(res, 401, err("Admin key required."));
    const body = await readBody(req);
    const title = String(body.title || "").trim();
    const description = String(body.description || "").trim();
    const date = String(body.date || "").trim();
    const time = String(body.time || "").trim();
    const location = String(body.location || "").trim();
    const category = String(body.category || "General").trim();
    const capacity = parseInt(body.capacity, 10) || 0;

    if (!title || !date || capacity <= 0) {
      return sendJson(res, 400, err("Title, date, and a capacity greater than 0 are required."));
    }

    const event = { id: newId("evt"), title, description, date, time, location, category, capacity, featured: false };
    events.push(event);
    await saveEvents();
    return sendJson(res, 201, eventToJson(event));
  }

  if (req.method === "PATCH" && remainder !== "") {
    // Partial update — used today for the "feature this opportunity" toggle
    // (promoting it to the public page's spotlight banner) but accepts any
    // known field, so it can also be used for quick edits later.
    if (!isAdmin(req)) return sendJson(res, 401, err("Admin key required."));
    const id = remainder;
    const idx = events.findIndex((e) => e.id === id);
    if (idx === -1) return sendJson(res, 404, err("No opportunity found with that id."));
    const body = await readBody(req);
    const allowed = ["title", "description", "date", "time", "location", "category", "capacity", "featured"];
    for (const key of allowed) {
      if (Object.prototype.hasOwnProperty.call(body, key)) {
        events[idx][key] = key === "capacity" ? (parseInt(body[key], 10) || events[idx].capacity) : body[key];
      }
    }
    await saveEvents();
    return sendJson(res, 200, eventToJson(events[idx]));
  }

  if (req.method === "DELETE" && remainder !== "") {
    if (!isAdmin(req)) return sendJson(res, 401, err("Admin key required."));
    const id = remainder;
    const idx = events.findIndex((e) => e.id === id);
    if (idx === -1) return sendJson(res, 404, err("No opportunity found with that id."));
    events.splice(idx, 1);
    registrations = registrations.filter((r) => r.eventId !== id);
    await Promise.all([saveEvents(), saveRegistrations()]);
    return sendJson(res, 200, { deleted: id });
  }

  return sendJson(res, 405, err("Method not allowed on this endpoint."));
}

async function handleRegister(req, res) {
  if (req.method !== "POST") return sendJson(res, 405, err("Use POST to register."));
  const body = await readBody(req);
  const eventId = String(body.eventId || "").trim();
  const name = String(body.name || "").trim();
  const email = String(body.email || "").trim();
  const phone = String(body.phone || "").trim();
  const notes = String(body.notes || "").trim();

  if (!eventId || !name || !email) {
    return sendJson(res, 400, err("Name, email, and an opportunity are required."));
  }
  const event = events.find((e) => e.id === eventId);
  if (!event) return sendJson(res, 404, err("That opportunity is no longer available."));

  const registered = countRegistrationsFor(eventId);
  if (registered >= event.capacity) {
    return sendJson(res, 409, err("That opportunity is already full."));
  }

  const r = { id: newId("reg"), eventId, name, email, phone, notes, createdAt: new Date().toISOString() };
  registrations.push(r);
  await saveRegistrations();
  return sendJson(res, 201, r);
}

function handleRegistrations(req, res, query) {
  if (req.method !== "GET") return sendJson(res, 405, err("Method not allowed."));
  if (!isAdmin(req)) return sendJson(res, 401, err("Admin key required."));
  const filterEventId = query.get("eventId");
  const list = filterEventId ? registrations.filter((r) => r.eventId === filterEventId) : registrations;
  return sendJson(res, 200, list);
}

// ---- Server -----------------------------------------------------------------

const server = http.createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Admin-Key");
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const pathname = url.pathname;

  try {
    if (pathname === "/api/health") return handleHealth(req, res);
    if (pathname === "/api/events" || pathname.startsWith("/api/events/")) {
      const remainder = pathname.length > "/api/events".length
        ? pathname.slice("/api/events".length).replace(/^\//, "")
        : "";
      return await handleEvents(req, res, remainder);
    }
    if (pathname === "/api/register") return await handleRegister(req, res);
    if (pathname === "/api/registrations") return handleRegistrations(req, res, url.searchParams);
    return serveStatic(req, res, pathname);
  } catch (e) {
    console.error(e);
    return sendJson(res, 500, err("Unexpected server error."));
  }
});

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

ensureDataDir();
loadState();
if (events.length === 0) {
  seedSampleData();
  saveEvents();
}

// Write the effective admin key to a local file every startup, so it's easy
// to find on disk (data/ADMIN_KEY.txt) without having to scroll back through
// terminal output.
fs.writeFileSync(
  ADMIN_KEY_FILE,
  `Admin key for the console at /admin.html: ${ADMIN_KEY}\n\n` +
  `Change it by setting the ADMIN_KEY environment variable before starting\n` +
  `the server, e.g.:\n\n  ADMIN_KEY=my-secret-key node server.js\n`
);

server.listen(PORT, () => {
  console.log("=================================================");
  console.log(" Metro PD Community Volunteers server is running");
  console.log(` http://localhost:${PORT}`);
  console.log(` Admin key: ${ADMIN_KEY}  (also saved to data/ADMIN_KEY.txt)`);
  console.log("=================================================");
});
