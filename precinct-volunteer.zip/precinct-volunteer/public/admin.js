// GridLine volunteers — admin page logic

const API = "";
const PASSWORD_STORAGE = "gridline_admin_password";

const gateView = document.getElementById("gateView");
const adminView = document.getElementById("adminView");
const adminPasswordInput = document.getElementById("adminPasswordInput");
const gateMsg = document.getElementById("gateMsg");
const createForm = document.getElementById("createForm");
const createMsg = document.getElementById("createMsg");
const adminEventList = document.getElementById("adminEventList");
const registrationsList = document.getElementById("registrationsList");

let adminPassword = sessionStorage.getItem(PASSWORD_STORAGE) || "";

function authHeaders(extra = {}) {
  return Object.assign({ "X-Admin-Password": adminPassword }, extra);
}

function showApp() {
  gateView.style.display = "none";
  adminView.style.display = "block";
  loadAdminEvents();
}

function showGate(message) {
  adminView.style.display = "none";
  gateView.style.display = "block";
  if (message) {
    gateMsg.textContent = message;
    gateMsg.className = "form-msg error show";
  }
}

async function logIn() {
  const candidate = adminPasswordInput.value.trim();
  if (!candidate) return;
  adminPassword = candidate;
  try {
    // Check the password by calling something only an admin is allowed to see.
    const res = await fetch(`${API}/api/registrations`, { headers: authHeaders() });
    await res.text(); // read the body so the browser can finish and reuse the connection
    if (res.status === 401) {
      showGate("Wrong password. Try again.");
      return;
    }
    if (res.status === 429) {
      showGate("Too many wrong passwords. Wait a few minutes and try again.");
      return;
    }
    if (!res.ok) {
      showGate("Something went wrong on the server. Try again.");
      return;
    }
  } catch (err) {
    showGate("Can't reach the server. Make sure it's running, then try again.");
    return;
  }
  sessionStorage.setItem(PASSWORD_STORAGE, adminPassword);
  adminPasswordInput.value = "";
  gateMsg.className = "form-msg";
  showApp();
}

document.getElementById("unlockBtn").addEventListener("click", logIn);
adminPasswordInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") logIn();
});

document.getElementById("lockBtn").addEventListener("click", () => {
  sessionStorage.removeItem(PASSWORD_STORAGE);
  adminPassword = "";
  showGate();
});

createForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    title: document.getElementById("fTitle").value.trim(),
    description: document.getElementById("fDescription").value.trim(),
    category: document.getElementById("fCategory").value,
    date: document.getElementById("fDate").value,
    time: document.getElementById("fTime").value,
    location: document.getElementById("fLocation").value.trim(),
    capacity: document.getElementById("fCapacity").value
  };
  try {
    const res = await fetch(`${API}/api/events`, {
      method: "POST",
      headers: authHeaders({ "Content-Type": "application/json" }),
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Couldn't publish the opportunity.");
    createMsg.textContent = `Published "${data.title}." `;
    const seeIt = document.createElement("a");
    seeIt.href = "/#opportunities";
    seeIt.textContent = "See it on the public page →";
    seeIt.style.color = "inherit";
    seeIt.style.textDecoration = "underline";
    createMsg.appendChild(seeIt);
    createMsg.className = "form-msg success show";
    createForm.reset();
    document.getElementById("fCapacity").value = 10;
    loadAdminEvents();
  } catch (err) {
    createMsg.textContent = err.message;
    createMsg.className = "form-msg error show";
  }
});

const DEFAULT_CATEGORIES = [
  "Community Outreach", "Neighborhood Safety", "Youth Programs",
  "Special Events", "Search & Rescue", "Administrative Support", "General"
];

function refreshCategoryOptions(events) {
  const select = document.getElementById("fCategory");
  const previousValue = select.value;
  const inUse = [...new Set(events.map(e => e.category).filter(Boolean))];
  const combined = [...new Set([...DEFAULT_CATEGORIES, ...inUse])];
  select.innerHTML = combined.map(c => `<option>${escapeHtml(c)}</option>`).join("");
  if (combined.includes(previousValue)) select.value = previousValue;
}

async function loadAdminEvents() {
  const res = await fetch(`${API}/api/events`);
  const events = await res.json();
  events.sort((a, b) => (a.date || "").localeCompare(b.date || ""));
  refreshCategoryOptions(events);

  if (events.length === 0) {
    adminEventList.innerHTML = `<p class="muted">No opportunities posted yet.</p>`;
    return;
  }

  adminEventList.innerHTML = "";
  events.forEach(evt => {
    const item = document.createElement("div");
    item.className = "admin-list-item";
    item.innerHTML = `
      <div class="row-top">
        <h4>${escapeHtml(evt.title)}</h4>
        <span class="badge-count">${evt.registered}/${evt.capacity}</span>
      </div>
      <div class="sub">${escapeHtml(evt.date)} ${escapeHtml(evt.time || "")} · ${escapeHtml(evt.location || "")} · ${escapeHtml(evt.category || "")}</div>
      <div class="btn-row">
        <button class="btn btn-outline btn-small" data-view="${evt.id}">View sign-ups</button>
        <button class="btn btn-feature btn-small ${evt.featured ? "is-active" : ""}" data-feature="${evt.id}">${evt.featured ? "★ Featured" : "☆ Feature"}</button>
        <button class="btn btn-outline btn-small" data-invite="${evt.id}">Copy invite</button>
        <button class="btn btn-danger btn-small" data-delete="${evt.id}">Delete</button>
      </div>
      <div class="invite-box" id="invite-${evt.id}"></div>
    `;
    item.querySelector("[data-view]").addEventListener("click", () => loadRegistrations(evt.id, evt.title));
    item.querySelector("[data-feature]").addEventListener("click", () => toggleFeatured(evt));
    item.querySelector("[data-invite]").addEventListener("click", () => showInvite(evt));
    item.querySelector("[data-delete]").addEventListener("click", () => deleteEvent(evt.id, evt.title));
    adminEventList.appendChild(item);
  });
}

async function toggleFeatured(evt) {
  try {
    const res = await fetch(`${API}/api/events/${evt.id}`, {
      method: "PATCH",
      headers: authHeaders({ "Content-Type": "application/json" }),
      body: JSON.stringify({ featured: !evt.featured })
    });
    await res.text(); // read the body so the browser can finish and reuse the connection
    if (res.status === 401) { showGate("Your session expired. Log in again."); return; }
    if (!res.ok) throw new Error("Couldn't update that opportunity.");
    loadAdminEvents();
  } catch (err) {
    alert(err.message);
  }
}

// Builds a ready-to-send invite message for an opportunity. There's no
// outbound email/SMS wired up here (that would need real mail-server
// credentials this app doesn't have), so instead this gives staff a
// one-click, correctly-formatted draft — with the live sign-up link and all
// the event details already filled in — to paste into whatever they already
// use to reach volunteers (email, a text blast, a newsletter, social media).
function buildInviteText(evt) {
  const link = `${window.location.origin}/#opportunities`;
  const when = [evt.date, evt.time].filter(Boolean).join(" at ");
  const spotsLine = evt.remaining > 0
    ? `${evt.remaining} of ${evt.capacity} spots are still open.`
    : `This one is currently full, but keep an eye out for the next one.`;
  return `Subject: Volunteers needed — ${evt.title}

Hi neighbor,

The Community Engagement Division is looking for volunteers for "${evt.title}."

When: ${when || "TBD"}
Where: ${evt.location || "TBD"}
${evt.description ? "\n" + evt.description + "\n" : ""}
${spotsLine}

Sign up here: ${link}

Thank you for considering it — every bit of help makes a difference.
— Metro PD Community Engagement Division`;
}

function showInvite(evt) {
  const box = document.getElementById(`invite-${evt.id}`);
  const isOpen = box.classList.contains("show");
  // Close any other open invite boxes so only one is visible at a time.
  document.querySelectorAll(".invite-box.show").forEach(b => { if (b !== box) b.classList.remove("show"); });
  if (isOpen) { box.classList.remove("show"); return; }

  const text = buildInviteText(evt);
  box.textContent = text;
  box.classList.add("show");

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      const original = box.textContent;
      box.textContent = "Copied to clipboard ✓\n\n" + original;
    }).catch(() => { /* clipboard permissions denied — text is still shown to copy manually */ });
  }
}

async function deleteEvent(id, title) {
  if (!confirm(`Delete "${title}"? This also removes its sign-ups.`)) return;
  const res = await fetch(`${API}/api/events/${id}`, {
    method: "DELETE",
    headers: authHeaders()
  });
  await res.text();
  if (res.ok) {
    loadAdminEvents();
    registrationsList.innerHTML = `<p class="muted">Select an opportunity above to view its sign-ups.</p>`;
  } else {
    alert("Couldn't delete that opportunity.");
  }
}

async function loadRegistrations(eventId, title) {
  registrationsList.innerHTML = `<p class="muted">Loading…</p>`;
  const res = await fetch(`${API}/api/registrations?eventId=${encodeURIComponent(eventId)}`, {
    headers: authHeaders()
  });
  if (res.status === 401) { showGate("Your session expired. Log in again."); return; }
  const regs = await res.json();

  if (regs.length === 0) {
    registrationsList.innerHTML = `<p class="muted">No sign-ups yet for "${escapeHtml(title)}."</p>`;
    return;
  }

  registrationsList.innerHTML = `<p class="muted" style="margin-bottom:10px">${regs.length} sign-up${regs.length === 1 ? "" : "s"} for "${escapeHtml(title)}"</p>`;
  regs.forEach(r => {
    const row = document.createElement("div");
    row.className = "reg-item";
    row.innerHTML = `
      <div class="reg-name">${escapeHtml(r.name)}</div>
      <div class="reg-meta">${escapeHtml(r.email)}${r.phone ? " · " + escapeHtml(r.phone) : ""}</div>
      ${r.notes ? `<div class="reg-meta">${escapeHtml(r.notes)}</div>` : ""}
    `;
    registrationsList.appendChild(row);
  });
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s == null ? "" : String(s);
  return div.innerHTML;
}

// Auto-unlock if a key is already stored in this browser session.
if (adminPassword) {
  fetch(`${API}/api/registrations`, { headers: authHeaders() }).then(async res => {
    await res.text(); // consume the body (see note above)
    if (res.ok) showApp(); else showGate();
  });
} else {
  showGate();
}
