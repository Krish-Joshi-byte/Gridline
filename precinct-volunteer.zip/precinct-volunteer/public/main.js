// Metro PD Community Volunteers — public page logic
// Talks to the Node backend (server.js) over the same origin. No CORS setup
// needed when served by the backend directly, but it sends permissive CORS
// headers anyway in case this is ever hosted separately.

const API = ""; // same-origin; set to e.g. "http://localhost:8080" if split out

let allEvents = [];
let activeCategory = "All";

const rosterContainer = document.getElementById("rosterContainer");
const filtersEl = document.getElementById("filters");
const resultCount = document.getElementById("resultCount");
const modalBackdrop = document.getElementById("modalBackdrop");
const modalTitle = document.getElementById("modalTitle");
const modalSub = document.getElementById("modalSub");
const registerForm = document.getElementById("registerForm");
const formMsg = document.getElementById("formMsg");
const submitBtn = document.getElementById("submitBtn");
const spotlight = document.getElementById("spotlight");
const spotlightItems = document.getElementById("spotlightItems");

function fmtDate(dateStr) {
  // dateStr expected as YYYY-MM-DD
  const parts = (dateStr || "").split("-");
  if (parts.length !== 3) return { month: "--", day: "--" };
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  return {
    month: d.toLocaleString("en-US", { month: "short" }).toUpperCase(),
    day: String(d.getDate())
  };
}

function fmtTime(t) {
  if (!t) return "";
  const [h, m] = t.split(":").map(Number);
  if (isNaN(h)) return t;
  const period = h >= 12 ? "PM" : "AM";
  const h12 = ((h + 11) % 12) + 1;
  return `${h12}:${String(m).padStart(2, "0")} ${period}`;
}

async function loadEvents() {
  try {
    const res = await fetch(`${API}/api/events`);
    if (!res.ok) throw new Error("Failed to load opportunities");
    allEvents = await res.json();
    allEvents.sort((a, b) => (a.date || "").localeCompare(b.date || ""));
    renderSpotlight();
    renderFilters();
    renderRoster();
  } catch (err) {
    rosterContainer.innerHTML = `<div class="empty-state"><h3>Couldn't load opportunities</h3><p>Make sure the server is running, then refresh the page.</p></div>`;
  }
}

function renderSpotlight() {
  const featured = allEvents.filter(e => e.featured && e.remaining > 0);
  if (featured.length === 0) {
    spotlight.classList.remove("show");
    spotlightItems.innerHTML = "";
    return;
  }
  spotlightItems.innerHTML = "";
  featured.forEach(evt => {
    const { month, day } = fmtDate(evt.date);
    const row = document.createElement("div");
    row.className = "spotlight-item";
    row.innerHTML = `
      <span class="sp-title">${escapeHtml(evt.title)}</span>
      <span class="sp-meta">${month} ${day} · ${fmtTime(evt.time)}${evt.location ? " · " + escapeHtml(evt.location) : ""}</span>
      <span class="sp-spots">${evt.remaining} of ${evt.capacity} spots open</span>
    `;
    spotlightItems.appendChild(row);
  });
  spotlight.classList.add("show");
}

function renderFilters() {
  const categories = ["All", ...new Set(allEvents.map(e => e.category).filter(Boolean))];
  filtersEl.innerHTML = "";
  categories.forEach(cat => {
    const chip = document.createElement("button");
    chip.className = "chip" + (cat === activeCategory ? " active" : "");
    chip.textContent = cat;
    chip.addEventListener("click", () => {
      activeCategory = cat;
      renderFilters();
      renderRoster();
    });
    filtersEl.appendChild(chip);
  });
}

function renderRoster() {
  const visible = activeCategory === "All"
    ? allEvents
    : allEvents.filter(e => e.category === activeCategory);

  resultCount.textContent = visible.length
    ? `${visible.length} opportunit${visible.length === 1 ? "y" : "ies"}`
    : "";

  if (visible.length === 0) {
    rosterContainer.innerHTML = `
      <div class="empty-state">
        <h3>No open opportunities right now</h3>
        <p>Check back soon — new ones are posted regularly.</p>
      </div>`;
    return;
  }

  const roster = document.createElement("div");
  roster.className = "roster";

  visible.forEach(evt => {
    const { month, day } = fmtDate(evt.date);
    const full = evt.remaining <= 0;
    const row = document.createElement("div");
    row.className = "roster-row" + (evt.featured ? " is-featured" : "");
    row.innerHTML = `
      <div class="date-block">
        <div class="month">${month}</div>
        <div class="day">${day}</div>
      </div>
      <div class="roster-main">
        <div class="tag-row">
          <span class="category-tag">${escapeHtml(evt.category || "General")}</span>
          ${evt.featured ? `<span class="featured-tag">Urgent need</span>` : ""}
        </div>
        <h3>${escapeHtml(evt.title)}</h3>
        <p class="meta">${fmtTime(evt.time)}${evt.time && evt.location ? " · " : ""}${escapeHtml(evt.location || "")}</p>
        <p class="desc">${escapeHtml(evt.description || "")}</p>
      </div>
      <div class="roster-side">
        <span class="spots ${full ? "full" : ""}">
          ${full ? "Full" : `<strong>${evt.remaining}</strong> of ${evt.capacity} spots open`}
        </span>
        <button class="btn ${full ? "btn-outline" : "btn-navy"} btn-small" ${full ? "disabled" : ""} data-id="${evt.id}">
          ${full ? "Full" : "Sign up"}
        </button>
      </div>
    `;
    if (!full) {
      row.querySelector("button").addEventListener("click", () => openModal(evt));
    }
    roster.appendChild(row);
  });

  rosterContainer.innerHTML = "";
  rosterContainer.appendChild(roster);
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s == null ? "" : String(s);
  return div.innerHTML;
}

function openModal(evt) {
  document.getElementById("eventId").value = evt.id;
  modalTitle.textContent = evt.title;
  modalSub.textContent = `${fmtDate(evt.date).month} ${fmtDate(evt.date).day} · ${fmtTime(evt.time)} · ${evt.location || ""}`;
  formMsg.className = "form-msg";
  formMsg.textContent = "";
  registerForm.reset();
  document.getElementById("eventId").value = evt.id;
  submitBtn.disabled = false;
  submitBtn.textContent = "Confirm sign-up";
  modalBackdrop.classList.remove("hidden");
}

function closeModal() {
  modalBackdrop.classList.add("hidden");
}

document.getElementById("cancelBtn").addEventListener("click", closeModal);
modalBackdrop.addEventListener("click", (e) => {
  if (e.target === modalBackdrop) closeModal();
});

registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  submitBtn.disabled = true;
  submitBtn.textContent = "Submitting…";

  const payload = {
    eventId: document.getElementById("eventId").value,
    name: document.getElementById("regName").value.trim(),
    email: document.getElementById("regEmail").value.trim(),
    phone: document.getElementById("regPhone").value.trim(),
    notes: document.getElementById("regNotes").value.trim()
  };

  try {
    const res = await fetch(`${API}/api/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Something went wrong.");

    formMsg.textContent = "You're signed up. A coordinator may follow up by email before the date.";
    formMsg.className = "form-msg success show";
    submitBtn.textContent = "Signed up";
    await loadEvents();
    setTimeout(closeModal, 1600);
  } catch (err) {
    formMsg.textContent = err.message;
    formMsg.className = "form-msg error show";
    submitBtn.disabled = false;
    submitBtn.textContent = "Confirm sign-up";
  }
});

loadEvents();
