#!/bin/sh
# Starts the Metro PD Community Volunteers server (needs Java 11 or newer).
# Usage:   ./run.sh
#          PORT=9090 ADMIN_PASSWORD=mynewpassword ./run.sh
cd "$(dirname "$0")" || exit 1

if ! command -v java >/dev/null 2>&1; then
  echo "Java isn't installed (or isn't on your PATH)."
  echo "Install a JDK, version 11 or newer (free: https://adoptium.net), then run this again."
  exit 1
fi

if command -v javac >/dev/null 2>&1; then
  mkdir -p out || exit 1
  javac -d out server/PrecinctVolunteerServer.java || exit 1
  exec java -cp out PrecinctVolunteerServer
else
  # No javac on the PATH: Java 11+ can compile and run a single source file directly.
  exec java server/PrecinctVolunteerServer.java
fi
