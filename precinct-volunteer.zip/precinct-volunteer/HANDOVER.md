# Handover — Metro PD Community Volunteers

**Status: working, tested, ready to run.**

## What this is

A small volunteer sign-up app for a police department's community
engagement division:

- **Public page** (`/`) — residents browse open volunteer opportunities and
  sign up.
- **Admin console** (`/admin.html`) — staff post/delete opportunities,
  spotlight ones that need volunteers, generate invite messages, and see
  who's signed up.

## How to run it

```bash
node server.js
```

Run from the project root (the folder `server.js` is in). Requires only
Node.js — nothing to install. Then open:

- Public page: **http://localhost:8080**
- Admin console: **http://localhost:8080/admin.html**

**Admin key:** `precinct-admin-2026` by default. It's printed in the
terminal on startup and also saved to `data/ADMIN_KEY.txt`. Change it with
`ADMIN_KEY=your-key node server.js`.

## What changed in this pass, and why

| Problem reported | What was done |
|---|---|
| Frontend couldn't reach the backend | The backend was originally written in Java, but had never been compiled/run in this environment (no JDK available across two prior sessions) — most likely the actual cause. Rewrote it as `server.js` (plain Node, zero dependencies) and tested every route end-to-end before handing it back. |
| Didn't know the admin key | Key is unchanged (`precinct-admin-2026`), but it's now also written to `data/ADMIN_KEY.txt` on every startup, and the login screen says where to find it. |
| Wanted a way to prompt people to join events | Added a **Feature** toggle (highlights an opportunity in an "Urgently need volunteers" banner on the public page) and a **Copy invite** button (generates a ready-to-send email/text draft with event details + sign-up link). No real email/SMS sending — that needs mail-provider credentials this project doesn't have. |
| Wanted the "Gridline" project's look | Reskinned both pages using Gridline's actual design tokens: dark near-black surfaces, blue accent, IBM Plex Sans, thin borders, tinted status colors. |

## What's verified vs. what isn't

**Verified by actually running it:** server starts, serves both pages/CSS/JS,
all API routes (health, list/create/patch/delete events, register, list
registrations), admin-key auth (missing/wrong/correct), capacity limits
(409 when full), CORS preflight, and cascading delete of registrations.

**Not verified:** the browser UI itself hasn't been clicked through by a
human (no browser available in the build environment). Worth doing a quick
pass — post an opportunity, sign up as a visitor, feature something, copy an
invite, delete something — before treating this as fully done.

## Known limitations (unchanged from before, still worth knowing)

- **No database** — two JSON files (`data/events.json`,
  `data/registrations.json`), fine for one server instance at small scale.
- **Shared admin key, not real accounts** — no per-admin audit trail.
- **No real outbound email/SMS** — invites are copy-paste drafts only.
- **No HTTPS** — put a reverse proxy (nginx/Caddy) in front for anything
  beyond local/dev use.

## Where things live

```
precinct-volunteer/
├── server.js                          ← run this
├── server/PrecinctVolunteerServer.java ← old Java backend, kept for reference only
├── public/                            ← index.html, admin.html, main.js, admin.js, styles.css
├── data/                              ← JSON "database" + ADMIN_KEY.txt (created on first run)
├── README.md                          ← fuller setup + API reference
└── HANDOFF_NOTES.md                   ← detailed session-by-session history, if you want the full story
```

This file is the short version. `HANDOFF_NOTES.md` has the longer,
session-by-session account of decisions and trade-offs if you need the
detail — this one's meant to be readable in under two minutes.
