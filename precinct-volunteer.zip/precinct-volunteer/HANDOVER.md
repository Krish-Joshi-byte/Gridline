# Handover — GridLine Community Volunteers

**Status: Java back end compiled, run and tested. Ready to run.**

## What this is

Volunteer sign-up app for a police department's community engagement division.
Public page (`/`) for residents; admin page (`/admin.html`) for staff, protected
by a single password. Front end is HTML/CSS/JavaScript in `public/`; back end is
Java in `server/PrecinctVolunteerServer.java` (JDK only, no dependencies).

## Run

```bash
java server/PrecinctVolunteerServer.java     # needs Java 11+
```

Public: http://localhost:8080 — Admin: http://localhost:8080/admin.html
Admin password: `adm1n` by default (change with `ADMIN_PASSWORD=...`).

## History in brief

- Sessions 1–3: built the app; the Java backend was never compiled, so Session 3
  switched to a Node port as a workaround.
- Session 4: Java back end compiled and tested (JDK 21) and made primary again.
- Session 5 (this pass): admin login is now a plain **password** (default
  `adm1n`) instead of a long key; header renamed `X-Admin-Password`, env var
  `ADMIN_PASSWORD`, file `data/ADMIN_PASSWORD.txt`. Added a wrong-password
  lockout (10 tries / 5 min per address), Enter-to-log-in, and clear links between
  the two pages (Admin login on the public page, Volunteer page / View public
  page on the admin page, "See it on the public page" after publishing). Both
  pages now use the GridLine name. The old Node `server.js` was removed because
  it no longer matches the front end.

## Verified vs. not

Verified with JDK 21, curl and headless Chromium: compile is clean under
`-Xlint:all`; all API routes and error cases; password login, wrong password,
lockout; publish → appears on public page; feature, invite, view sign-ups,
delete; navigation between the pages.

Not verified: other Java versions (code sticks to Java 11 features), Windows
`run.bat`, Google Fonts (test sandbox had no internet).

## Limitations

One shared password, no HTTPS, no CAPTCHA on sign-up, plain-JSON storage of
contact details, no real email/SMS. See README.
