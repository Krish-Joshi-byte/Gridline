# GridLine — Community Volunteers (Police Community Engagement)

A small full-stack app for a police department's volunteer program.

- **Public page** (`/`) — residents see the volunteer opportunities and sign up to help.
- **Admin page** (`/admin.html`) — staff log in with a password and post the
  opportunities they want the community to join.
- **Front end:** plain HTML, CSS and JavaScript in `public/`.
- **Back end:** Java, one file (`server/PrecinctVolunteerServer.java`), no
  libraries. It serves both pages and the data.

The two pages link to each other: **"Admin login"** in the top bar (and footer)
of the public page, **"Volunteer page" / "View public page"** on the admin page,
and a **"See it on the public page"** link right after you publish something.

## Run it

You need Java 11 or newer (`java -version`; free download: https://adoptium.net).

```bash
java server/PrecinctVolunteerServer.java
```

Run that from the `precinct-volunteer` folder (it also works from the `server`
folder or the folder above). `./run.sh` and `run.bat` do the same thing if you
prefer a shortcut.

Then open:

- Public page: **http://localhost:8080**
- Admin page: **http://localhost:8080/admin.html**

## Admin password

The default password is **`adm1n`**. It's also printed in the terminal at startup
and saved in `data/ADMIN_PASSWORD.txt`.

It's easy to guess, so before other people can reach the server, set your own:

```bash
ADMIN_PASSWORD=mynewpassword java server/PrecinctVolunteerServer.java
```

(Windows Command Prompt: `set ADMIN_PASSWORD=mynewpassword & java server\PrecinctVolunteerServer.java`)

After 10 wrong passwords from one address, that address is locked out for 5 minutes.

Other setting: `PORT` (default 8080), e.g. `PORT=9090`.

## Using it

**Staff** — go to `/admin.html`, enter the password, then:

1. Fill in *Post a new opportunity* (title, what volunteers will do, category,
   date, time, location, how many volunteers) and click **Publish**. It shows up
   on the public page immediately.
2. In *Current opportunities*:
   - **Feature** — puts it in the "Urgently need volunteers" banner on the public page.
   - **Copy invite** — makes an email/text draft (details + sign-up link) and copies
     it. Nothing is sent automatically; paste it into your own email or text.
   - **View sign-ups** — names, emails, phones and notes.
   - **Delete** — removes it and its sign-ups.

**Residents** — on the public page, filter by category, click **Sign up**, enter
name and email (phone and notes optional). Spots count down live, full
opportunities can't be joined, and the same email can't join the same one twice.

## How data is stored

No database. After every change the server writes `data/events.json`
(opportunities) and `data/registrations.json` (sign-ups) and reloads them on the
next start. Five sample opportunities are created on the very first run;
deleting them later does not bring them back. An unreadable data file is copied
to `*.corrupt-<time>` instead of being overwritten.

## API

| Method | Path                 | Needs password | Purpose                                   |
|--------|----------------------|----------------|-------------------------------------------|
| GET    | `/api/events`        | no             | List opportunities                        |
| POST   | `/api/events`        | yes            | Create an opportunity                     |
| PATCH  | `/api/events/{id}`   | yes            | Update fields (e.g. `{"featured": true}`) |
| DELETE | `/api/events/{id}`   | yes            | Delete an opportunity and its sign-ups    |
| POST   | `/api/register`      | no             | Sign up for an opportunity                |
| GET    | `/api/registrations` | yes            | List sign-ups (optional `?eventId=`)      |
| GET    | `/api/health`        | no             | Health check                              |

The password goes in an `X-Admin-Password` request header.

## Project layout

```
precinct-volunteer/
├── server/PrecinctVolunteerServer.java   back end (Java)
├── public/                               front end
│   ├── index.html  main.js               public page
│   ├── admin.html  admin.js              admin page
│   └── styles.css
├── data/                                 saved data + ADMIN_PASSWORD.txt (auto-created)
├── run.sh / run.bat                      optional shortcuts
└── README.md  HANDOVER.md  HANDOFF_NOTES.md
```

## Known limitations

- **One shared password**, not individual accounts. No record of who did what.
- **No HTTPS.** For anything beyond a local demo, put a reverse proxy
  (Caddy/nginx) in front; otherwise the password and volunteers' contact details
  travel unencrypted.
- **No CAPTCHA or rate limit** on the public sign-up form.
- **Contact details are stored in plain JSON files.**
- **No real email/SMS.** Invites are copy-and-paste drafts.
