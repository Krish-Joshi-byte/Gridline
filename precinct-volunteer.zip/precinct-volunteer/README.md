# Metro PD Community Volunteers

A small full-stack app for a police department's community-volunteer program:

- **Public page** (`/`) — residents browse open volunteer opportunities, see
  which ones urgently need people, and register.
- **Admin console** (`/admin.html`) — staff post new opportunities, feature
  ones that need volunteers most, generate a ready-to-send invite message,
  delete old opportunities, and view who signed up.
- **Backend** — `server.js`, plain Node.js, zero dependencies (no `npm
  install` needed at all — it only uses Node's built-in `http`/`fs` modules).

## Why Node instead of the Java version

The project originally shipped with a hand-rolled Java backend
(`server/PrecinctVolunteerServer.java`, still included for reference). Across
two earlier working sessions, that file was carefully written and reviewed
but **never actually run through a real `javac`** — no JDK was available in
the environment that built it. That's the most likely explanation for "the
frontend doesn't connect": if the backend never starts, every request from
`index.html`/`admin.html` fails, which matches the symptom exactly.

`server.js` is a line-for-line port of the same API to Node, and unlike the
Java file, **it has actually been started and exercised against every route**
(health check, listing, creating, featuring, deleting, registering, admin
auth, static file serving, CORS preflight) in the environment that built it.
Node is also much more commonly pre-installed than a full JDK, so this should
remove the "can't get it running at all" problem too.

## Requirements

Just [Node.js](https://nodejs.org) (any reasonably recent version — this was
built and tested on Node 22, but anything 16+ will work). Check with:

```bash
node --version
```

## Run it

From the **project root** (the folder this README is in):

```bash
node server.js
```

You should see:

```
=================================================
 Metro PD Community Volunteers server is running
 http://localhost:8080
 Admin key: precinct-admin-2026  (also saved to data/ADMIN_KEY.txt)
=================================================
```

Then open **http://localhost:8080** for the public page, and
**http://localhost:8080/admin.html** for the admin console.

### Finding the admin key

The default admin key is **`precinct-admin-2026`**. If you lose track of it:

- It's printed to the terminal every time the server starts (see above), and
- It's written to **`data/ADMIN_KEY.txt`** on every startup, so you can just
  open that file.

Change it by setting the `ADMIN_KEY` environment variable before starting:

```bash
ADMIN_KEY=my-secret-key node server.js
```

Change it before showing this to anyone outside your household.

### Changing the port

```bash
PORT=9090 node server.js
```

## Getting people to actually sign up (the "invite" feature)

Two admin-console tools for promoting an opportunity, in the "Current
opportunities" panel:

- **Feature** (☆ / ★) — marks an opportunity as urgently needing volunteers.
  Featured opportunities with open spots show up in a highlighted "Urgently
  need volunteers" banner at the top of the public page.
- **Copy invite** — generates a ready-to-send email/text draft (subject line,
  event details, and a live link to the sign-up page) and copies it to your
  clipboard. There's no outbound email/SMS wired into this app — that would
  need real mail-server credentials this project doesn't have — so instead
  this gives you a correctly-formatted draft to paste into whatever you
  already use to reach volunteers: your email client, a text blast, a
  newsletter, or a social post.

## How data is stored

There's no database. Every time an opportunity is posted/edited/deleted or
someone registers, the server rewrites two JSON files using Node's built-in
`JSON.stringify`/`JSON.parse` (no hand-rolled parser to worry about):

- `data/events.json`
- `data/registrations.json`

They're reloaded automatically on the next startup. This is intentionally
simple — see `HANDOFF_NOTES.md` for how to replace it with a real database
later without changing the frontend.

## Project layout

```
precinct-volunteer/
├── server.js                          ← the backend (Node, run this)
├── server/
│   └── PrecinctVolunteerServer.java   ← original Java version, kept for reference
├── public/                            ← served as static files by the backend
│   ├── index.html                     ← public volunteer listing + sign-up + spotlight banner
│   ├── admin.html                     ← admin console
│   ├── main.js                        ← public page logic
│   ├── admin.js                       ← admin page logic (feature toggle, invite drafts)
│   └── styles.css                     ← shared styling (matches the Gridline design system)
├── data/                              ← auto-created JSON "database" + ADMIN_KEY.txt
├── README.md
└── HANDOFF_NOTES.md                   ← notes on decisions + history
```

## API reference

| Method | Path                | Auth        | Purpose                                          |
|--------|---------------------|-------------|---------------------------------------------------|
| GET    | `/api/events`       | none        | List all opportunities                             |
| POST   | `/api/events`       | admin key   | Create an opportunity                              |
| PATCH  | `/api/events/{id}`  | admin key   | Update fields on an opportunity (e.g. `featured`)  |
| DELETE | `/api/events/{id}`  | admin key   | Delete an opportunity + its sign-ups               |
| POST   | `/api/register`     | none        | Register for an opportunity                        |
| GET    | `/api/registrations`| admin key   | List all sign-ups (optionally `?eventId=`)         |
| GET    | `/api/health`       | none        | Health check                                       |

Admin requests authenticate with an `X-Admin-Key` header matching `ADMIN_KEY`.
