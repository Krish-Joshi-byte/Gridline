import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * GridLine Community Volunteers — backend server.
 *
 * Pure JDK (Java 11+), zero external dependencies: it uses
 * com.sun.net.httpserver.HttpServer, which ships with the JDK. It also serves
 * the static front end from ./public, so the browser talks to one origin.
 *
 * Run from the project root (the folder that contains "public" and "data"):
 *
 *   java server/PrecinctVolunteerServer.java            (no separate compile step)
 *   -- or --
 *   javac -d out server/PrecinctVolunteerServer.java && java -cp out PrecinctVolunteerServer
 *
 * (run.sh / run.bat in the project root do this for you.)
 *
 * Data model
 *   Event        - a volunteer opportunity the admin publishes
 *   Registration - a community member signing up for an Event
 *
 * Persistence: after every change the state is written to data/events.json and
 * data/registrations.json (atomically, via a temp file), and reloaded on startup.
 * This is intentionally simple — there is no database.
 *
 * Admin auth: one shared password, sent by the admin console as the
 * X-Admin-Password header. Default is "adm1n"; set your own with the
 * ADMIN_PASSWORD environment variable.
 */
public class PrecinctVolunteerServer {

    // ---- Configuration -----------------------------------------------------

    static final int PORT = intFromEnv("PORT", 8080);
    static final String DEFAULT_ADMIN_PASSWORD = "adm1n";
    static final String ADMIN_PASSWORD = stringFromEnv("ADMIN_PASSWORD", DEFAULT_ADMIN_PASSWORD);

    static final Path ROOT = findProjectRoot();
    static final Path DATA_DIR = ROOT.resolve("data");
    static final Path EVENTS_FILE = DATA_DIR.resolve("events.json");
    static final Path REGISTRATIONS_FILE = DATA_DIR.resolve("registrations.json");
    static final Path ADMIN_PASSWORD_FILE = DATA_DIR.resolve("ADMIN_PASSWORD.txt");
    static final Path PUBLIC_DIR = ROOT.resolve("public");

    static final int MAX_BODY_BYTES = 64 * 1024;
    static final int MAX_CAPACITY = 10_000;
    static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    /**
     * Finds the project folder (the one containing "public"), so the server starts
     * correctly no matter where the command is run from: the project folder itself,
     * the server/ folder, or the folder just above the project.
     */
    static Path findProjectRoot() {
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        Path[] candidates = { cwd, cwd.getParent(), cwd.resolve("precinct-volunteer") };
        for (Path c : candidates) {
            if (c != null && Files.isDirectory(c.resolve("public"))) return c;
        }
        return cwd;
    }

    static int intFromEnv(String name, int def) {
        String v = System.getenv(name);
        if (v == null) return def;
        try { return Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return def; }
    }

    static String stringFromEnv(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }

    // ---- In-memory state ---------------------------------------------------
    // Every read or write of these lists happens while holding LOCK. That keeps
    // "check capacity, then add a sign-up" atomic, so two people racing for the
    // last spot can't both get it, and saves can't interleave.

    static final Object LOCK = new Object();
    static final List<Event> events = new ArrayList<>();
    static final List<Registration> registrations = new ArrayList<>();

    // ---- Entry point -------------------------------------------------------

    public static void main(String[] args) throws IOException {
        if (!Files.isDirectory(PUBLIC_DIR)) {
            System.err.println("Can't find the 'public' folder in " + ROOT);
            System.err.println("Run the command from inside the precinct-volunteer folder (the one that contains 'public' and 'data').");
            System.exit(1);
        }
        Files.createDirectories(DATA_DIR);

        boolean firstRun = !Files.exists(EVENTS_FILE);
        synchronized (LOCK) {
            loadState();
            if (firstRun && events.isEmpty()) {
                seedSampleData();
                saveEvents();
            }
        }
        writeAdminPasswordFile();

        HttpServer server;
        try {
            server = HttpServer.create(new InetSocketAddress(PORT), 0);
        } catch (BindException e) {
            System.err.println("Port " + PORT + " is already in use. Stop the other program, or pick another port:");
            System.err.println("  PORT=9090 ./run.sh");
            System.exit(1);
            return;
        }
        server.createContext("/api/health", withCors(PrecinctVolunteerServer::handleHealth));
        server.createContext("/api/events", withCors(PrecinctVolunteerServer::handleEvents));
        server.createContext("/api/register", withCors(PrecinctVolunteerServer::handleRegister));
        server.createContext("/api/registrations", withCors(PrecinctVolunteerServer::handleRegistrations));
        server.createContext("/", withCors(PrecinctVolunteerServer::handleStatic));
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> server.stop(1)));

        System.out.println("=================================================");
        System.out.println(" GridLine Community Volunteers server is running");
        System.out.println(" http://localhost:" + PORT);
        System.out.println(" Admin page: http://localhost:" + PORT + "/admin.html");
        System.out.println(" Admin password: " + ADMIN_PASSWORD + "  (also saved to data/ADMIN_PASSWORD.txt)");
        if (ADMIN_PASSWORD.equals(DEFAULT_ADMIN_PASSWORD)) {
            System.out.println(" NOTE: \"" + DEFAULT_ADMIN_PASSWORD + "\" is the default password and is easy to guess. Before other");
            System.out.println("       people can reach this server, set your own:  ADMIN_PASSWORD=yourpassword");
        }
        System.out.println("=================================================");
    }

    // ---- Models ------------------------------------------------------------

    static final class Event {
        String id, title, description, date, time, location, category;
        int capacity;
        boolean featured;

        Event copy() {
            Event e = new Event();
            e.id = id; e.title = title; e.description = description; e.date = date; e.time = time;
            e.location = location; e.category = category; e.capacity = capacity; e.featured = featured;
            return e;
        }

        private JsonObj base() {
            return new JsonObj()
                    .str("id", id).str("title", title).str("description", description)
                    .str("date", date).str("time", time).str("location", location)
                    .str("category", category).num("capacity", capacity).bool("featured", featured);
        }

        /** What gets written to data/events.json (no derived fields). */
        String persistJson() { return base().toString(); }

        /** What the API returns: the stored fields plus live sign-up counts. Call while holding LOCK. */
        String apiJson() {
            int registered = countRegistrationsFor(id);
            return base().num("registered", registered)
                    .num("remaining", Math.max(0, capacity - registered)).toString();
        }
    }

    static final class Registration {
        String id, eventId, name, email, phone, notes, createdAt;

        String toJson() {
            return new JsonObj()
                    .str("id", id).str("eventId", eventId).str("name", name).str("email", email)
                    .str("phone", phone).str("notes", notes).str("createdAt", createdAt).toString();
        }
    }

    /** Call while holding LOCK. */
    static int countRegistrationsFor(String eventId) {
        int c = 0;
        for (Registration r : registrations) if (r.eventId.equals(eventId)) c++;
        return c;
    }

    /** Call while holding LOCK. */
    static Event findEvent(String id) {
        for (Event e : events) if (e.id.equals(id)) return e;
        return null;
    }

    // ---- Errors ------------------------------------------------------------

    /** Thrown by handlers to send a JSON error with a specific status code. */
    static final class HttpError extends RuntimeException {
        private static final long serialVersionUID = 1L;
        final int status;
        HttpError(int status, String message) { super(message); this.status = status; }
    }

    // ---- Route handlers ----------------------------------------------------

    static void handleHealth(HttpExchange ex) throws IOException {
        sendJson(ex, 200, "{\"status\":\"ok\"}");
    }

    static void handleEvents(HttpExchange ex) throws IOException {
        String method = ex.getRequestMethod();
        String id = subPath(ex, "/api/events");

        switch (method) {
            case "GET":
                if (id.isEmpty()) { listEvents(ex); return; }
                break;
            case "POST":
                if (id.isEmpty()) { createEvent(ex); return; }
                break;
            case "PATCH":
                if (!id.isEmpty()) { updateEvent(ex, id); return; }
                break;
            case "DELETE":
                if (!id.isEmpty()) { deleteEvent(ex, id); return; }
                break;
            default:
                break;
        }
        throw new HttpError(405, "Method not allowed on this endpoint.");
    }

    static void listEvents(HttpExchange ex) throws IOException {
        StringBuilder sb = new StringBuilder("[");
        synchronized (LOCK) {
            for (int i = 0; i < events.size(); i++) {
                if (i > 0) sb.append(',');
                sb.append(events.get(i).apiJson());
            }
        }
        sb.append(']');
        sendJson(ex, 200, sb.toString());
    }

    static void createEvent(HttpExchange ex) throws IOException {
        requireAdmin(ex);
        Map<String, Object> body = readJsonBody(ex);

        Event e = new Event();
        e.title = str(body, "title");
        e.description = str(body, "description");
        e.date = str(body, "date");
        e.time = str(body, "time");
        e.location = str(body, "location");
        e.category = str(body, "category");
        if (e.category.isEmpty()) e.category = "General";
        e.capacity = intOf(body.get("capacity"), 0);
        e.featured = false;

        if (e.title.isEmpty() || e.date.isEmpty() || e.capacity <= 0) {
            throw new HttpError(400, "Title, date, and a capacity greater than 0 are required.");
        }
        validateEvent(e);

        String json;
        synchronized (LOCK) {
            e.id = newId("evt");
            events.add(e);
            saveEvents();
            json = e.apiJson();
        }
        sendJson(ex, 201, json);
    }

    /** Partial update. Used by the console's Feature toggle, but accepts any editable field. */
    static void updateEvent(HttpExchange ex, String id) throws IOException {
        requireAdmin(ex);
        Map<String, Object> body = readJsonBody(ex);

        String json;
        synchronized (LOCK) {
            Event current = findEvent(id);
            if (current == null) throw new HttpError(404, "No opportunity found with that id.");

            Event u = current.copy();
            if (body.containsKey("title")) u.title = str(body, "title");
            if (body.containsKey("description")) u.description = str(body, "description");
            if (body.containsKey("date")) u.date = str(body, "date");
            if (body.containsKey("time")) u.time = str(body, "time");
            if (body.containsKey("location")) u.location = str(body, "location");
            if (body.containsKey("category")) {
                u.category = str(body, "category");
                if (u.category.isEmpty()) u.category = "General";
            }
            if (body.containsKey("capacity")) {
                int cap = intOf(body.get("capacity"), 0);
                if (cap <= 0) throw new HttpError(400, "Capacity must be greater than 0.");
                u.capacity = cap;
            }
            if (body.containsKey("featured")) {
                Boolean f = boolOf(body.get("featured"));
                if (f == null) throw new HttpError(400, "\"featured\" must be true or false.");
                u.featured = f;
            }
            if (u.title.isEmpty() || u.date.isEmpty()) {
                throw new HttpError(400, "Title and date can't be empty.");
            }
            validateEvent(u);

            int registered = countRegistrationsFor(id);
            if (u.capacity < registered) {
                throw new HttpError(400, "Capacity can't be lower than the " + registered
                        + " people already signed up.");
            }

            events.set(events.indexOf(current), u);
            saveEvents();
            json = u.apiJson();
        }
        sendJson(ex, 200, json);
    }

    static void deleteEvent(HttpExchange ex, String id) throws IOException {
        requireAdmin(ex);
        synchronized (LOCK) {
            Event e = findEvent(id);
            if (e == null) throw new HttpError(404, "No opportunity found with that id.");
            events.remove(e);
            registrations.removeIf(r -> r.eventId.equals(id));
            saveEvents();
            saveRegistrations();
        }
        sendJson(ex, 200, new JsonObj().str("deleted", id).toString());
    }

    static void handleRegister(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("POST")) throw new HttpError(405, "Use POST to register.");
        Map<String, Object> body = readJsonBody(ex);

        String eventId = str(body, "eventId");
        String name = str(body, "name");
        String email = str(body, "email");
        String phone = str(body, "phone");
        String notes = str(body, "notes");

        if (eventId.isEmpty() || name.isEmpty() || email.isEmpty()) {
            throw new HttpError(400, "Name, email, and an opportunity are required.");
        }
        if (name.length() > 120 || email.length() > 200 || phone.length() > 40 || notes.length() > 1000) {
            throw new HttpError(400, "One of those fields is too long.");
        }
        if (!EMAIL.matcher(email).matches()) {
            throw new HttpError(400, "Please enter a valid email address.");
        }

        String json;
        synchronized (LOCK) {
            Event event = findEvent(eventId);
            if (event == null) throw new HttpError(404, "That opportunity is no longer available.");

            int registered = 0;
            for (Registration existing : registrations) {
                if (!existing.eventId.equals(eventId)) continue;
                registered++;
                if (existing.email.equalsIgnoreCase(email)) {
                    throw new HttpError(409, "That email address is already signed up for this opportunity.");
                }
            }
            if (registered >= event.capacity) throw new HttpError(409, "That opportunity is already full.");

            Registration r = new Registration();
            r.id = newId("reg");
            r.eventId = eventId;
            r.name = name;
            r.email = email;
            r.phone = phone;
            r.notes = notes;
            r.createdAt = Instant.now().toString();
            registrations.add(r);
            saveRegistrations();
            json = r.toJson();
        }
        sendJson(ex, 201, json);
    }

    static void handleRegistrations(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("GET")) throw new HttpError(405, "Method not allowed.");
        requireAdmin(ex);

        String filterEventId = null;
        String query = ex.getRequestURI().getRawQuery();
        if (query != null) {
            for (String part : query.split("&")) {
                String[] kv = part.split("=", 2);
                if (kv.length == 2 && kv[0].equals("eventId")) filterEventId = urlDecode(kv[1]);
            }
        }

        StringBuilder sb = new StringBuilder("[");
        synchronized (LOCK) {
            boolean first = true;
            for (Registration r : registrations) {
                if (filterEventId != null && !r.eventId.equals(filterEventId)) continue;
                if (!first) sb.append(',');
                first = false;
                sb.append(r.toJson());
            }
        }
        sb.append(']');
        sendJson(ex, 200, sb.toString());
    }

    // ---- Static file serving -----------------------------------------------

    static void handleStatic(HttpExchange ex) throws IOException {
        String reqPath = ex.getRequestURI().getPath();
        if (reqPath.startsWith("/api/")) throw new HttpError(404, "No such API route.");
        if (!ex.getRequestMethod().equals("GET")) throw new HttpError(405, "Method not allowed.");
        if (reqPath.equals("/")) reqPath = "/index.html";

        Path target;
        try {
            target = PUBLIC_DIR.resolve(reqPath.substring(1)).normalize();
        } catch (InvalidPathException e) {
            target = null;
        }
        if (target == null || !target.startsWith(PUBLIC_DIR) || !Files.isRegularFile(target)) {
            byte[] notFound = "404 — page not found.".getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
            ex.sendResponseHeaders(404, notFound.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(notFound); }
            return;
        }

        byte[] data = Files.readAllBytes(target);
        ex.getResponseHeaders().set("Content-Type", contentType(target.toString()));
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        ex.sendResponseHeaders(200, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    static String contentType(String path) {
        if (path.endsWith(".html")) return "text/html; charset=utf-8";
        if (path.endsWith(".css")) return "text/css; charset=utf-8";
        if (path.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (path.endsWith(".json")) return "application/json; charset=utf-8";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    // ---- Helpers -----------------------------------------------------------

    /** The part of the URL path after the given prefix, without surrounding slashes. */
    static String subPath(HttpExchange ex, String prefix) {
        String path = ex.getRequestURI().getPath();
        String rest = path.length() > prefix.length() ? path.substring(prefix.length()) : "";
        return rest.replaceAll("^/+|/+$", "");
    }

    // Wrong-password throttle: after MAX_FAILED_LOGINS wrong passwords from one address,
    // that address is locked out for LOCKOUT_MS. Stops someone from simply guessing.
    static final int MAX_FAILED_LOGINS = 10;
    static final long LOCKOUT_MS = 5 * 60 * 1000;
    static final Map<String, long[]> failedLogins = new HashMap<>(); // address -> {count, windowStartMillis}

    static void requireAdmin(HttpExchange ex) {
        String addr = ex.getRemoteAddress().getAddress().getHostAddress();
        long now = System.currentTimeMillis();
        synchronized (failedLogins) {
            if (failedLogins.size() > 1000) failedLogins.values().removeIf(f -> now - f[1] > LOCKOUT_MS);
            long[] f = failedLogins.get(addr);
            if (f != null && now - f[1] > LOCKOUT_MS) { failedLogins.remove(addr); f = null; }
            if (f != null && f[0] >= MAX_FAILED_LOGINS) {
                throw new HttpError(429, "Too many wrong passwords. Try again in a few minutes.");
            }
        }

        String given = ex.getRequestHeaders().getFirst("X-Admin-Password");
        if (given == null) throw new HttpError(401, "Admin password required.");

        boolean ok = MessageDigest.isEqual(
                given.getBytes(StandardCharsets.UTF_8), ADMIN_PASSWORD.getBytes(StandardCharsets.UTF_8));
        synchronized (failedLogins) {
            if (ok) {
                failedLogins.remove(addr);
                return;
            }
            failedLogins.computeIfAbsent(addr, k -> new long[] {0, now})[0]++;
        }
        throw new HttpError(401, "Wrong admin password.");
    }

    static void validateEvent(Event e) {
        if (e.title.length() > 120) throw new HttpError(400, "Title is too long (120 characters max).");
        if (e.description.length() > 2000) throw new HttpError(400, "Description is too long (2000 characters max).");
        if (e.location.length() > 200) throw new HttpError(400, "Location is too long (200 characters max).");
        if (e.category.length() > 60) throw new HttpError(400, "Category is too long (60 characters max).");
        if (e.capacity > MAX_CAPACITY) throw new HttpError(400, "Capacity can't be more than " + MAX_CAPACITY + ".");
        try {
            LocalDate.parse(e.date);
        } catch (DateTimeParseException ex) {
            throw new HttpError(400, "Date must look like 2026-10-06.");
        }
        if (!e.time.isEmpty()) {
            try {
                LocalTime.parse(e.time);
            } catch (DateTimeParseException ex) {
                throw new HttpError(400, "Time must look like 17:30.");
            }
        }
    }

    static String urlDecode(String s) {
        try { return URLDecoder.decode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    static String newId(String prefix) {
        return prefix + "_" + UUID.randomUUID().toString().replace("-", "").substring(0, 14);
    }

    static String str(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v == null ? "" : String.valueOf(v).trim();
    }

    static int intOf(Object v, int def) {
        if (v instanceof Number) return ((Number) v).intValue();
        if (v instanceof String) {
            try { return Integer.parseInt(((String) v).trim()); } catch (NumberFormatException e) { return def; }
        }
        return def;
    }

    static Boolean boolOf(Object v) {
        if (v instanceof Boolean) return (Boolean) v;
        if (v instanceof String) {
            String s = ((String) v).trim();
            if (s.equalsIgnoreCase("true")) return Boolean.TRUE;
            if (s.equalsIgnoreCase("false")) return Boolean.FALSE;
        }
        return null;
    }

    static String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) {
                out.write(buf, 0, n);
                if (out.size() > MAX_BODY_BYTES) throw new HttpError(413, "Request is too large.");
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    static Map<String, Object> readJsonBody(HttpExchange ex) throws IOException {
        String raw = readBody(ex);
        try {
            return Json.parseObject(raw);
        } catch (IllegalArgumentException e) {
            throw new HttpError(400, "Request body must be valid JSON.");
        }
    }

    static void sendJson(HttpExchange ex, int status, String json) throws IOException {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(status, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    /** Wraps a handler with CORS headers, OPTIONS preflight support, and uniform error handling. */
    static HttpHandler withCors(HttpHandler inner) {
        return ex -> {
            ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
            ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, X-Admin-Password");
            try {
                if (ex.getRequestMethod().equals("OPTIONS")) {
                    ex.sendResponseHeaders(204, -1);
                    return;
                }
                inner.handle(ex);
            } catch (HttpError e) {
                try { sendJson(ex, e.status, new JsonObj().str("error", e.getMessage()).toString()); }
                catch (IOException ignored) { }
            } catch (Exception e) {
                e.printStackTrace();
                try { sendJson(ex, 500, "{\"error\":\"Unexpected server error.\"}"); }
                catch (IOException ignored) { }
            } finally {
                ex.close();
            }
        };
    }

    // ---- Persistence -------------------------------------------------------
    // Call the save* methods while holding LOCK.

    static void saveEvents() {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < events.size(); i++) {
            sb.append("  ").append(events.get(i).persistJson());
            if (i < events.size() - 1) sb.append(',');
            sb.append('\n');
        }
        sb.append("]\n");
        writeAtomically(EVENTS_FILE, sb.toString());
    }

    static void saveRegistrations() {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < registrations.size(); i++) {
            sb.append("  ").append(registrations.get(i).toJson());
            if (i < registrations.size() - 1) sb.append(',');
            sb.append('\n');
        }
        sb.append("]\n");
        writeAtomically(REGISTRATIONS_FILE, sb.toString());
    }

    /** Write to a temp file, then move it into place, so a crash can't leave a half-written data file. */
    static void writeAtomically(Path path, String content) {
        try {
            Path tmp = path.resolveSibling(path.getFileName() + ".tmp");
            Files.write(tmp, content.getBytes(StandardCharsets.UTF_8));
            try {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            System.err.println("Failed to write " + path + ": " + e.getMessage());
        }
    }

    static void loadState() {
        for (Map<String, Object> m : readObjectArray(EVENTS_FILE)) {
            Event e = new Event();
            e.id = str(m, "id");
            if (e.id.isEmpty()) e.id = newId("evt");
            e.title = str(m, "title");
            e.description = str(m, "description");
            e.date = str(m, "date");
            e.time = str(m, "time");
            e.location = str(m, "location");
            e.category = str(m, "category");
            if (e.category.isEmpty()) e.category = "General";
            e.capacity = intOf(m.get("capacity"), 0);
            Boolean f = boolOf(m.get("featured"));
            e.featured = f != null && f;
            events.add(e);
        }
        for (Map<String, Object> m : readObjectArray(REGISTRATIONS_FILE)) {
            Registration r = new Registration();
            r.id = str(m, "id");
            if (r.id.isEmpty()) r.id = newId("reg");
            r.eventId = str(m, "eventId");
            r.name = str(m, "name");
            r.email = str(m, "email");
            r.phone = str(m, "phone");
            r.notes = str(m, "notes");
            r.createdAt = str(m, "createdAt");
            registrations.add(r);
        }
    }

    /**
     * Reads a JSON array of objects from a data file. A missing file is just an empty list.
     * A file that can't be parsed is copied aside (never overwritten silently) so no data is lost.
     */
    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> readObjectArray(Path file) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (!Files.exists(file)) return out;
        try {
            String text = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            Object parsed = Json.parse(text);
            if (!(parsed instanceof List)) throw new IllegalArgumentException("expected a JSON array");
            for (Object item : (List<Object>) parsed) {
                if (item instanceof Map) out.add((Map<String, Object>) item);
            }
        } catch (IOException | IllegalArgumentException e) {
            Path backup = file.resolveSibling(file.getFileName() + ".corrupt-" + System.currentTimeMillis());
            System.err.println("Couldn't read " + file.getFileName() + " (" + e.getMessage() + ").");
            try {
                Files.copy(file, backup);
                System.err.println("Saved a copy of the unreadable file as " + backup.getFileName() + " and started empty.");
            } catch (IOException ioe) {
                System.err.println("Also couldn't back it up: " + ioe.getMessage());
            }
            out.clear();
        }
        return out;
    }

    /** Writes the current admin password to data/ADMIN_PASSWORD.txt on every start, so it's easy to find. */
    static void writeAdminPasswordFile() {
        String text = "Admin password for the page at /admin.html: " + ADMIN_PASSWORD + "\n\n"
                + "Change it by setting the ADMIN_PASSWORD environment variable before starting\n"
                + "the server, e.g.:\n\n  ADMIN_PASSWORD=mynewpassword java server/PrecinctVolunteerServer.java\n";
        try {
            Files.write(ADMIN_PASSWORD_FILE, text.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Couldn't write " + ADMIN_PASSWORD_FILE + ": " + e.getMessage());
        }
    }

    static void seedSampleData() {
        Object[][] seed = {
                {"National Night Out Booth", "Staff the department's community booth: hand out safety literature, run the child ID kit table, and answer questions from neighbors.", "2026-10-06", "17:00", "Riverside Park Pavilion", "Community Outreach", 8, true},
                {"Neighborhood Watch Kickoff", "Help set up chairs, sign in attendees, and hand out starter packets for a new Neighborhood Watch group's first meeting.", "2026-10-14", "18:30", "Precinct 3 Community Room", "Neighborhood Safety", 6, false},
                {"Bike Rodeo Safety Course", "Assist officers running a youth bicycle safety course: helmet fitting, obstacle course setup, and course marshaling.", "2026-10-18", "10:00", "Lincoln Elementary Parking Lot", "Youth Programs", 12, false},
                {"Senior Vial of Life Deliveries", "Ride along with a volunteer coordinator to deliver Vial of Life kits to seniors who requested them.", "2026-10-25", "09:00", "Meet at Precinct 1", "Community Outreach", 5, true},
                {"Records Room Filing Support", "Help the records division scan and file archived paperwork. No law-enforcement background needed, just attention to detail.", "2026-11-02", "13:00", "Police Headquarters, Records Division", "Administrative Support", 3, false}
        };
        for (Object[] s : seed) {
            Event e = new Event();
            e.id = newId("evt");
            e.title = (String) s[0];
            e.description = (String) s[1];
            e.date = (String) s[2];
            e.time = (String) s[3];
            e.location = (String) s[4];
            e.category = (String) s[5];
            e.capacity = (Integer) s[6];
            e.featured = (Boolean) s[7];
            events.add(e);
        }
    }

    // ---- Minimal JSON support (no external dependencies) --------------------

    /** Tiny builder for flat JSON objects. */
    static final class JsonObj {
        private final StringBuilder sb = new StringBuilder("{");
        private boolean first = true;

        private void key(String k) {
            if (!first) sb.append(',');
            first = false;
            sb.append('"').append(k).append("\":");
        }

        JsonObj str(String k, String v) { key(k); sb.append('"').append(Json.esc(v)).append('"'); return this; }
        JsonObj num(String k, long v) { key(k); sb.append(v); return this; }
        JsonObj bool(String k, boolean v) { key(k); sb.append(v); return this; }

        @Override public String toString() { return sb.toString() + "}"; }
    }

    static final class Json {
        static String esc(String s) {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder(s.length() + 8);
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            return sb.toString();
        }

        /** Parses any JSON value. Objects become Map, arrays List, numbers Double, plus String/Boolean/null. */
        static Object parse(String text) {
            Parser p = new Parser(text == null ? "" : text);
            Object v = p.value(0);
            p.skipWhitespace();
            if (p.i != p.s.length()) throw p.fail("Unexpected trailing characters");
            return v;
        }

        /** Parses a JSON object, or throws IllegalArgumentException if the text isn't one. */
        @SuppressWarnings("unchecked")
        static Map<String, Object> parseObject(String text) {
            Object v = parse(text);
            if (!(v instanceof Map)) throw new IllegalArgumentException("Expected a JSON object");
            return (Map<String, Object>) v;
        }

        private static final class Parser {
            final String s;
            int i = 0;

            Parser(String s) { this.s = s; }

            IllegalArgumentException fail(String msg) {
                return new IllegalArgumentException(msg + " at position " + i);
            }

            void skipWhitespace() {
                while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
            }

            Object value(int depth) {
                if (depth > 32) throw fail("Too deeply nested");
                skipWhitespace();
                if (i >= s.length()) throw fail("Unexpected end of input");
                char c = s.charAt(i);
                switch (c) {
                    case '{': return object(depth);
                    case '[': return array(depth);
                    case '"': return string();
                    case 't': literal("true"); return Boolean.TRUE;
                    case 'f': literal("false"); return Boolean.FALSE;
                    case 'n': literal("null"); return null;
                    default: return number();
                }
            }

            Map<String, Object> object(int depth) {
                Map<String, Object> map = new LinkedHashMap<>();
                i++; // {
                skipWhitespace();
                if (i < s.length() && s.charAt(i) == '}') { i++; return map; }
                while (true) {
                    skipWhitespace();
                    if (i >= s.length() || s.charAt(i) != '"') throw fail("Expected a string key");
                    String key = string();
                    skipWhitespace();
                    if (i >= s.length() || s.charAt(i) != ':') throw fail("Expected ':'");
                    i++;
                    map.put(key, value(depth + 1));
                    skipWhitespace();
                    if (i >= s.length()) throw fail("Unterminated object");
                    char c = s.charAt(i++);
                    if (c == '}') return map;
                    if (c != ',') throw fail("Expected ',' or '}'");
                }
            }

            List<Object> array(int depth) {
                List<Object> list = new ArrayList<>();
                i++; // [
                skipWhitespace();
                if (i < s.length() && s.charAt(i) == ']') { i++; return list; }
                while (true) {
                    list.add(value(depth + 1));
                    skipWhitespace();
                    if (i >= s.length()) throw fail("Unterminated array");
                    char c = s.charAt(i++);
                    if (c == ']') return list;
                    if (c != ',') throw fail("Expected ',' or ']'");
                }
            }

            String string() {
                i++; // opening quote
                StringBuilder sb = new StringBuilder();
                while (true) {
                    if (i >= s.length()) throw fail("Unterminated string");
                    char c = s.charAt(i++);
                    if (c == '"') return sb.toString();
                    if (c != '\\') { sb.append(c); continue; }
                    if (i >= s.length()) throw fail("Unterminated escape");
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/': sb.append('/'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'n': sb.append('\n'); break;
                        case 'r': sb.append('\r'); break;
                        case 't': sb.append('\t'); break;
                        case 'u':
                            if (i + 4 > s.length()) throw fail("Bad \\u escape");
                            try {
                                sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            } catch (NumberFormatException nfe) {
                                throw fail("Bad \\u escape");
                            }
                            i += 4;
                            break;
                        default: throw fail("Bad escape");
                    }
                }
            }

            void literal(String word) {
                if (!s.startsWith(word, i)) throw fail("Unexpected token");
                i += word.length();
            }

            Object number() {
                int start = i;
                while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
                if (start == i) throw fail("Unexpected character");
                try {
                    return Double.valueOf(s.substring(start, i));
                } catch (NumberFormatException e) {
                    throw fail("Bad number");
                }
            }
        }
    }
}
