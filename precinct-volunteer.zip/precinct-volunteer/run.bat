@echo off
rem Starts the Metro PD Community Volunteers server (needs Java 11 or newer).
rem Usage:   run.bat
rem          set PORT=9090 & set ADMIN_PASSWORD=mynewpassword & run.bat
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  echo Java isn't installed or isn't on your PATH.
  echo Install a JDK, version 11 or newer ^(free: https://adoptium.net^), then run this again.
  exit /b 1
)

where javac >nul 2>nul
if %errorlevel%==0 (
  if not exist out mkdir out
  javac -d out server\PrecinctVolunteerServer.java || exit /b 1
  java -cp out PrecinctVolunteerServer
) else (
  rem No javac on the PATH: Java 11+ can compile and run a single source file directly.
  java server\PrecinctVolunteerServer.java
)
